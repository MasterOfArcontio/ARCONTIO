using Arcontio.Core.Logging;
using System;
using System.Collections.Generic;
using Arcontio.Core.DevTools;
using Unity.VisualScripting.FullSerializer;
using UnityEngine;
using UnityEngine.LightTransport;
using static UnityEditor.PlayerSettings;

namespace Arcontio.Core
{
    /// <summary>
    /// World:
    /// Contiene stato globale + component store.
    ///
    /// Day10 (patch):
    /// - Gli "occluder" NON sono più una struttura separata: sono oggetti del mondo (WorldObjectInstance)
    /// - Manteniamo una OcclusionMap interna (griglia) come CACHE derivata da World.Objects
    ///   per query veloci: BlocksVision/BlocksMovement.
    ///
    /// Nota:
    /// - Restiamo coerenti col Core Standard: 1 object per cell.
    /// - La cache viene aggiornata quando crei/distruggi oggetti o quando SetOccluder (wrapper) modifica celle.
    /// </summary>
    public sealed class World
    {
        // ============================================================
        // GLOBAL / CONFIG
        // ============================================================

        public GlobalState Global;

        // Dimensione griglia simulatore (spostabile in game_params.json)
        public int MapWidth { get; private set; }
        public int MapHeight { get; private set; }

        // ============================================================
        // DEBUG / TELEMETRY (view-only diagnostics)
        // ============================================================

        /// <summary>
        /// Telemetria FOV (debug): heatmap per NPC accumulata in finestre di N tick.
        ///
        /// Per design:
        /// - se null: feature disabilitata da game_params.json.
        /// - se presente: viene aggiornata dai system che calcolano percezione
        ///   e avanzata 1 volta per tick dal SimulationHost.
        ///
        /// IMPORTANTISSIMO:
        /// - Questa NON è logica di simulazione.
        /// - È solo un canale di osservabilità per la view/debug.
        /// </summary>
        public DebugFovTelemetry DebugFovTelemetry { get; private set; }

        /// <summary>
        /// LandmarkRegistry (v0.02 Day2): registro oggettivo dei landmark.
        ///
        /// Nota:
        /// - È world-side (non per-NPC).
        /// - Viene costruito in bootstrap (SimulationHost) dopo il seeding della mappa.
        /// - La view può leggerlo in modo read-only tramite GetNpcLandmarkOverlayData.
        /// </summary>
        public LandmarkRegistry LandmarkRegistry { get; private set; }

        /// <summary>
        /// Debug token logs (Patch 0.01P2):
        /// cache per rendere osservabili le comunicazioni simboliche (TokenEnvelope).
        ///
        /// Perché è qui e non nella View:
        /// - Il TokenDelivery/Assimilation è core.
        /// - La view deve restare read-only sul World.
        /// - Senza un cache persistente, i token "spariscono" dopo il tick (TokenBus è una coda).
        ///
        /// IMPORTANTISSIMO:
        /// - Questo NON influisce su decisioni NPC.
        /// - È diagnostica: può essere disabilitata/ignorata senza cambiare gameplay.
        /// </summary>
        public readonly Dictionary<int, DebugNpcTokenLog> DebugNpcTokens = new();

        /// <summary>
        /// TokenOutQueue (Patch 0.01P3 extension): coda "deferred" di TokenEnvelope OUT.
        ///
        /// Motivazione architetturale:
        /// - Alcuni System (es. MemoryEncodingSystem) NON ricevono TokenBus in input.
        /// - Tuttavia, in alcuni casi vogliamo generare comunicazioni *event-driven* (es. report di furto)
        ///   nello stesso tick in cui viene percepito un evento.
        /// - Per non violare le dipendenze (System -> TokenBus) aggiungiamo una coda nel World.
        ///
        /// Flusso:
        /// - i System chiamano world.QueueTokenOut(...)
        /// - SimulationHost, in un punto noto e centrale, chiama world.FlushQueuedTokenOut(_tokenBusOut)
        /// - il flush usa PublishTokenOut(...) quindi mantiene osservabilità + balloon.
        ///
        /// IMPORTANTISSIMO:
        /// - È una coda *runtime* (non persistenza), vale solo per il tick corrente.
        /// - Non è logica di gameplay autonoma: è un meccanismo di collegamento tra stage.
        /// </summary>
        private readonly List<TokenEnvelope> _queuedTokenOut = new(256);

        /// <summary>
        /// Helper difensivo: ritorna (o crea) il log di un NPC.
        ///
        /// Nota: Non facciamo pruning qui: il log è bounded internamente.
        /// </summary>
        public DebugNpcTokenLog GetOrCreateDebugNpcTokenLog(int npcId)
        {
            if (!DebugNpcTokens.TryGetValue(npcId, out var log) || log == null)
            {
                log = new DebugNpcTokenLog();
                DebugNpcTokens[npcId] = log;
            }
            return log;
        }

        /// <summary>
        /// PublishTokenOut (Patch 0.01P3):
        /// Punto *canonico* dove un TokenEnvelope viene considerato "detto" (OUT).
        ///
        /// Motivazione architetturale:
        /// - In 0.01 ci sono più posti che possono pubblicare su TokenBusOut:
        ///   - TokenEmissionPipeline (regole di emission)
        ///   - SimulationHost (iniezioni di scenario/debug come T7)
        /// - Se logghiamo OUT solo dentro TokenEmissionPipeline, perdiamo tutto ciò che nasce altrove.
        ///
        /// Quindi:
        /// - Chiunque voglia pubblicare un token OUT deve passare da qui.
        /// - Qui facciamo SOLO side-effect di debug/UX:
        ///   1) aggiorniamo DebugNpcTokenLog (per card UI)
        ///   2) emettiamo un NpcBalloonSignal (per fumetto sopra la testa)
        ///   3) pubblichiamo sul TokenBusOut (flusso reale)
        ///
        /// Nota:
        /// - Questo non modifica l'AI: è osservabilità.
        /// </summary>
        public void PublishTokenOut(TokenBus tokenBusOut, TokenEnvelope env)
        {
            // Difensivo: niente crash se qualcuno chiama con bus null.
            if (tokenBusOut == null) return;

            // 1) Log diagnostico (OUT)
            GetOrCreateDebugNpcTokenLog(env.SpeakerId).RecordOutgoing(env);

            // 2) Balloon (OUT)
            // SubjectId = listenerId: è l'informazione più utile in debug ("sto parlando a chi?").
            // Nota Patch 0.01P3 extension:
            // - Alcune comunicazioni hanno balloon dedicati (furto report vittima/testimone).
            // - Qui selezioniamo il kind in modo deterministico dal TokenType.
            var outKind = GetOutgoingBalloonKindForTokenType(env.Token.Type);
            EmitNpcBalloon(env.SpeakerId, outKind, subjectId: env.ListenerId);

            // 3) Effettiva pubblicazione
            tokenBusOut.Publish(env);
        }

        /// <summary>
        /// QueueTokenOut (Patch 0.01P3 extension):
        /// Accoda un envelope OUT per essere pubblicato più tardi dal SimulationHost.
        ///
        /// Nota:
        /// - Non facciamo Publish qui perché i System che chiamano questa funzione non hanno
        ///   accesso al TokenBusOut.
        /// - Non facciamo nemmeno balloon/log qui: verranno applicati nel flush tramite PublishTokenOut.
        /// </summary>
        public void QueueTokenOut(TokenEnvelope env)
        {
            _queuedTokenOut.Add(env);
        }

        /// <summary>
        /// FlushQueuedTokenOut (Patch 0.01P3 extension):
        /// Pubblica tutti gli envelope accodati su TokenBusOut passando dal punto canonico PublishTokenOut.
        ///
        /// Ritorna:
        /// - quanti envelope sono stati flushati.
        ///
        /// Nota:
        /// - Il flush è idempotente per tick: svuota la lista.
        /// - Chiamare flush più volte nello stesso tick è lecito (es. pre e post-command encoding).
        /// </summary>
        public int FlushQueuedTokenOut(TokenBus tokenBusOut)
        {
            if (_queuedTokenOut.Count == 0)
                return 0;

            int count = _queuedTokenOut.Count;

            for (int i = 0; i < _queuedTokenOut.Count; i++)
                PublishTokenOut(tokenBusOut, _queuedTokenOut[i]);

            _queuedTokenOut.Clear();
            return count;
        }

        /// <summary>
        /// Seleziona il balloon OUT in funzione del tipo di token.
        ///
        /// Design choice:
        /// - Per quasi tutti i token: TokenOut generico.
        /// - Per TheftReport*: balloon dedicati, perché sono un segnale sociale rilevante (crimine).
        /// </summary>
        private static NpcBalloonKind GetOutgoingBalloonKindForTokenType(TokenType type)
        {
            switch (type)
            {
                case TokenType.TheftReportVictim: return NpcBalloonKind.TheftReportVictimOut;
                case TokenType.TheftReportWitness: return NpcBalloonKind.TheftReportWitnessOut;
                default: return NpcBalloonKind.TokenOut;
            }
        }

        private OcclusionCell[] _occlusion; // size = MapWidth*MapHeight
        private struct OcclusionCell
        {
            public int OccluderObjectId; // 0 = none
            public bool BlocksVision;
            public bool BlocksMovement;
            public float VisionCost;
        }

        public WorldConfig Config { get; }

        /// <summary>
        /// Inizializza (o reinizializza) la mappa del simulatore.
        /// Attenzione: se lo chiami dopo aver creato oggetti, perderai gli indici.
        /// In pratica va chiamato in bootstrap (SimulationHost) prima del seeding.
        /// </summary>
        public void InitMap(int width, int height)
        {
            if (width <= 0) width = 1;
            if (height <= 0) height = 1;

            MapWidth = width;
            MapHeight = height;

            int size = MapWidth * MapHeight;

            _occlusion = new OcclusionCell[size];
            _objIdByCell = new int[size];
            _blocksVision = new bool[size];
            _blocksMovement = new bool[size];

            // Pulizia cache: default è ok per OcclusionCell/bool,
            // ma _objIdByCell deve essere inizializzato a -1 (empty).
            for (int i = 0; i < size; i++)
            {
                _occlusion[i] = default;
                _blocksVision[i] = false;
                _blocksMovement[i] = false;
                _objIdByCell[i] = -1;
            }
        }

        // ============================================================
        // DATA-DRIVEN DEFINITIONS
        // ============================================================

        // Definizioni logiche degli oggetti (caricate da ObjectDatabaseLoader)
        public readonly Dictionary<string, ObjectDef> ObjectDefs = new();

        // ============================================================
        // COMPONENT STORES (NPC)
        // ============================================================

        public readonly Dictionary<int, NpcCore> NpcCore = new();
        public readonly Dictionary<int, Needs> Needs = new();
        public readonly Dictionary<int, Social> Social = new();
        public readonly Dictionary<int, GridPosition> GridPos = new();
        public readonly Dictionary<int, CardinalDirection> NpcFacing = new();

        // ============================================================
        // ACTIVITY / ACTION (NPC)
        // ============================================================

        /// <summary>
        /// Stato di azione "corrente" per NPC (view/debug friendliness).
        /// 
        /// NOTE ARCHITETTURALI (ARCONTIO):
        /// - Non è una "AI brain" separata: è un piccolo stato descrittivo che rende osservabile
        ///   cosa l'NPC sta facendo in questo momento.
        /// - Viene aggiornato dai Command (intenti) e/o dai System (esecuzione fisica).
        /// - La View può leggerlo senza dover inferire azioni da segnali indiretti (movimento, fame, ecc.).
        /// </summary>
        public readonly Dictionary<int, NpcActionState> NpcAction = new();

        /// <summary>
        /// NpcBalloonSignals:
        /// Ultimo segnale "visuale" (balloon) per ciascun NPC.
        ///
        /// Nota:
        /// - È uno store di osservabilità, come NpcAction.
        /// - Viene scritto dal core quando accadono fatti rilevanti.
        /// - La view lo legge e decide come renderizzare (sprite, durata, layering).
        /// </summary>
        public readonly Dictionary<int, NpcBalloonSignal> NpcBalloonSignals = new();

        // Movimento come "intento" eseguito da un System.
        // Le Rule scrivono qui; il MovementSystem consuma e prova ad avanzare.
        //        public readonly Dictionary<int, MoveIntent> MoveIntents = new();

        // Memoria (per-NPC)
        public readonly Dictionary<int, MemoryStore> Memory = new();
        public readonly Dictionary<int, PersonalityMemoryParams> MemoryParams = new();

        // 1 store per NPC
        public readonly Dictionary<int, NpcObjectMemoryStore> NpcObjectMemory =
            new Dictionary<int, NpcObjectMemoryStore>(2048);

        

        // ============================================================
        // LANDMARK MEMORY (NPC-side, v0.02 Day3)
        // ============================================================
        //
        // Questo e� IL punto in cui ARCONTIO separa:
        // - "verit� oggettiva" (LandmarkRegistry, World-side, derivato dalla mappa)
        // - "conoscenza soggettiva" (NpcLandmarkMemory, per-NPC, imparata tramite esperienza)
        //
        // Day3 introduce:
        // - subset per NPC (non conosce tutto)
        // - cap per NPC + eviction (stale + over-cap)
        // - apprendimento event-driven (agganciato al movimento)
        //
        // Nota implementativa:
        // - teniamo lo store nel World perch�:
        //   1) e� un componente per-NPC (come Memory, Needs, Social, ecc.)
        //   2) la view deve poter leggere contatori in modo safe via TryGetNpcLandmarkDebugReport
        // - la logica di aggiornamento avviene tramite:
        //   - MovementSystem -> NotifyNpcMovedForLandmarkLearning(...)
        //   - NpcLandmarkMemorySystem -> eviction/cap (periodico)
        //
        public readonly Dictionary<int, NpcLandmarkMemory> NpcLandmarkMemory = new Dictionary<int, NpcLandmarkMemory>(2048);
// ============================================================
        // COMPONENT STORES (OBJECTS)
        // ============================================================

        // Oggetti nel mondo
        public readonly Dictionary<int, WorldObjectInstance> Objects = new();

        // Use state (letto occupato, ecc.)
        public readonly Dictionary<int, ObjectUseState> ObjectUse = new();

        // Food stock ?in-world? (pile/stockpile)
        public readonly Dictionary<int, FoodStockComponent> FoodStocks = new();
        // ============================================================
        // OWNERSHIP / POSSESSION (Pinned *belief*, NOT telepathy)
        // ============================================================
        //
        // Patch 5.1 (Ownership Pinned Memory - revised):
        //
        // IMPORTANTISSIMO:
        // In ARCONTIO distinguiamo SEMPRE tra:
        //  - Verità oggettiva del mondo (World/Facts)
        //  - Conoscenza soggettiva di un NPC (Perception + Memory)
        //
        // La "proprietà" (OwnerKind/OwnerId dentro FoodStockComponent) è un FATTO oggettivo.
        // Ma la "consapevolezza" che l'NPC ha di quel possesso NON deve essere telepatica:
        // se qualcuno ruba/distrugge uno stock fuori dalla vista dell'NPC,
        // l'NPC non deve "saperlo" finché non torna sul posto o riceve informazione mediata.
        //
        // Per risolvere il bug pratico ("ignora il mio cibo a terra se non è in memoria percettiva")
        // senza violare il manifesto, introduciamo quindi un ledger PINNED di tipo belief:
        //
        //  - è scritto quando lo stock viene creato/posato con OwnerId (cioè l'NPC *sa* di averlo)
        //  - NON viene cancellato automaticamente quando lo stock viene rubato/distrutto lontano
        //  - viene invalidato solo quando l'NPC ispeziona (arriva sulla cella attesa e non trova lo stock)
        //
        // Nota:
        // - Manteniamo solo la "last known cell" perché è sufficiente per pianificare:
        //   l'NPC può decidere di tornare lì a verificare.
        // - In futuro potremmo arricchire questa belief con timestamp, confidence, ecc.
        //
        public struct PinnedFoodStockBelief
        {
            // L'objectId dello stock che l'NPC crede di possedere.
            public int ObjectId;

            // Ultima cella nota dove l'NPC crede di aver lasciato lo stock.
            public int LastKnownX;
            public int LastKnownY;

            public bool IsValid => ObjectId != 0;
        }

        // npcId -> lista di stock privati "pinnati" come BELIEF.
        // NON è memoria percettiva, e non è "verità del mondo": è il promemoria interno "quel cibo è mio e sta lì".
        public readonly Dictionary<int, List<PinnedFoodStockBelief>> NpcPinnedFoodStockBeliefs = new();


        // Cibo privato per NPC (inventario v0)
        public readonly Dictionary<int, int> NpcPrivateFood = new();

        // Marker per distinguere "ho mangiato io" vs "mi manca cibo"
        // npcId -> ultimo tick in cui ha consumato cibo privato
        public readonly Dictionary<int, long> NpcLastPrivateFoodConsumeTick = new();

        // (Day10) Occluder component store per oggetti ?muro/porta?
        // Nota: un muro è un oggetto, e qui mettiamo i suoi flags runtime (vision/movement + cost).
        public readonly Dictionary<int, Occluder> ObjectOccluders = new();

        // ============================================================
        // MOVEMENT / SCAN (intent + execution state)
        // ============================================================

        /// <summary>
        /// Intento di movimento per NPC.
        /// - Scritto dalla decision pipeline (Rules/Decision).
        /// - Consumato dal MovementSystem (fisico).
        /// </summary>
        public readonly Dictionary<int, MoveIntent> NpcMoveIntents = new();

        /// <summary>
        /// Stato di scan direzionale per NPC.
        /// - "Nessuna visione a 360° gratuita": scan = 4 turn consecutivi.
        /// - Consumato da IdleScanSystem.
        /// </summary>
        public readonly Dictionary<int, ScanState> NpcScanStates = new();


        // ============================================================
        // INTERNAL GRID INDEXES / CACHES
        // ============================================================

        // 1 object per cell -> indice rapido cella->objId
        private int[] _objIdByCell; // length = MapWidth*MapHeight, -1 = empty

        // Cache occlusione: derivata dagli oggetti (ObjectOccluders o def flags)
        private bool[] _blocksVision;    // length = MapWidth*MapHeight
        private bool[] _blocksMovement;  // length = MapWidth*MapHeight

        // ============================================================
        // IDS
        // ============================================================

        private int _nextNpcId = 1;
        private int _nextObjectId = 1;

        // ============================================================
        // CTOR / INIT
        // ============================================================

        public World(WorldConfig config)
        {
            Config = config;
            InitMap(Config.Sim.worldWidth, Config.Sim.worldHeight);

            // ============================================================
            // LANDMARK REGISTRY (v0.02 Day2)
            // ============================================================
            // Nota:
            // - Qui istanziamo SOLO il contenitore.
            // - La build vera e propria avviene dopo il seeding (SimulationHost), quando
            //   oggetti come muri/porte sono stati piazzati sulla griglia.
            LandmarkRegistry = new LandmarkRegistry();

            // ============================================================
            // DEBUG FOV TELEMETRY (config-driven)
            // ============================================================
            // Nota:
            // - questa è una feature SOLO debug.
            // - la view la usa per disegnare overlay "heat" delle celle viste.
            // - viene attivata da game_params.json: debug_fov.enabled.
            //
            // Implementazione:
            // - accumulo per finestra di N tick
            // - double buffer read/write
            if (Config?.Sim != null && Config.Sim.debug_fov != null && Config.Sim.debug_fov.enabled)
            {
                int window = Config.Sim.debug_fov.window_ticks;
                if (window <= 0) window = 1;

                DebugFovTelemetry = new DebugFovTelemetry(MapWidth, MapHeight, window);
            }

            Global.EnableMemorySpatialFusion = false;
            Global.MemoryRegionSizeCells = 4;

            Global.MaxTokensPerEncounter = 2;
            Global.MaxTokensPerNpcPerDay = 50;
            Global.RepeatShareCooldownTicks = 0;

            Global.TokenDeliveryMaxRangeCells = 10;
            Global.EnableTokenLOS = true;
            Global.TokenReliabilityFalloffPerCell = 0.06f;
            Global.TokenIntensityFalloffPerCell = 0.04f;

            // ============================================================
            // Perception params (data-driven via game_params.json)
            // ============================================================
            // Prima erano hardcoded. Ora li leggiamo da SimulationParams.
            // Se valori non sono presenti o sono invalidi, facciamo fallback safe.
            int vr = Config?.Sim != null ? Config.Sim.npcVisionRangeCells : 6;
            if (vr <= 0) vr = 6;
            Global.NpcVisionRangeCells = vr;
            
            int ar = Config?.Sim != null ? Config.Sim.npcOperationalRangeCells : 8;
            if (ar <= 0) ar = 8;
            Global.NpcOperationalRangeCells = ar;

            bool useCone = Config?.Sim != null ? Config.Sim.npcVisionUseCone : true;
            Global.NpcVisionUseCone = useCone;

            // Cone slope:
            // - se npcVisionConeSlope > 0 => usalo.
            // - altrimenti, se npcVisionFovDegrees > 0 => calcola slope = tan(fov/2).
            float slope = Config?.Sim != null ? Config.Sim.npcVisionConeSlope : 1.0f;
            int fovDeg = Config?.Sim != null ? Config.Sim.npcVisionFovDegrees : 90;

            if (slope <= 0f && fovDeg > 0)
            {
                // half-angle in radianti
                // Esempio: FOV=90° => half=45° => tan(45)=1.
                float halfRad = (fovDeg * 0.5f) * Mathf.Deg2Rad;
                slope = Mathf.Tan(halfRad);
            }

            if (slope <= 0f) slope = 1.0f;

            // Legacy/back-compat: manteniamo anche HalfWidthPerStep per codice vecchio.
            Global.NpcVisionConeSlope = slope;
            Global.NpcVisionConeHalfWidthPerStep = slope;

            Global.Needs = NeedsConfig.Default();

            // ============================================================
            // Inventory params (data-driven via game_params.json)
            // ============================================================
            // Capienza inventario globale.
            // NOTA: oggi l'inventario è rappresentato principalmente da NpcPrivateFood (cibo trasportato),
            // ma la query World.GetInventoryFreeCapacity è pensata per diventare la fonte unica
            // anche quando introdurremo altri oggetti trasportabili.
            int invMax = Config?.Sim != null && Config.Sim.inventory != null ? Config.Sim.inventory.inventory_max_units : 3;
            if (invMax < 0) invMax = 0; // "0" è valido: significa che non può trasportare nulla.
            Global.InventoryMaxUnits = invMax;


            // ============================================================
            // Landmark pathfinding params (data-driven via game_params.json)
            // ============================================================
            // (v0.02 Day1)
            // Nota: qui NON implementiamo ancora il pathfinding a landmark.
            // Formalizziamo soltanto i parametri e li rendiamo disponibili nel GlobalState,
            // così la view può fare overlay/report e i Day successivi possono usare gli stessi valori.
            var lm = Config?.Sim != null ? Config.Sim.landmarks : null;
            if (lm != null)
            {
                Global.EnableLandmarkSystem = lm.enableLandmarkSystem;
                Global.MaxLandmarksPerNpc = lm.maxLandmarksPerNpc;
                Global.MaxEdgesPerNpc = lm.maxEdgesPerNpc;
                Global.MaxPoiAnchorsPerNpc = lm.maxPoiAnchorsPerNpc;
                Global.MaxWorldLandmarks = lm.maxWorldLandmarks;

                // Day3: eviction params (NPC-side)
                // "stale" = dopo quanti tick una conoscenza non vista pu� essere rimossa
                // "cooldown" = dopo una eviction, per quanti tick evitiamo di re-imparare lo stesso item (anti-thrashing)
                Global.LandmarkEvictionStaleTicks = lm.eviction != null ? lm.eviction.eviction_stale_ticks : 600;
                Global.LandmarkEvictionCooldownTicks = lm.eviction != null ? lm.eviction.eviction_cooldown_ticks : 120;
            }
            else
            {
                // Fallback safe se la sezione non esiste nel json.
                Global.EnableLandmarkSystem = false;
                Global.MaxLandmarksPerNpc = 64;
                Global.MaxEdgesPerNpc = 192;
                Global.MaxPoiAnchorsPerNpc = 32;
                Global.MaxWorldLandmarks = 512;

                // Day3 eviction defaults
                Global.LandmarkEvictionStaleTicks = 600;
                Global.LandmarkEvictionCooldownTicks = 120;
            }
        }

        /// <summary>
        /// (v0.02 Day2) Bootstrap API:
        /// ricostruisce LandmarkRegistry in base allo stato corrente della mappa.
        ///
        /// Deve essere chiamato:
        /// - DOPO che il seeding ha piazzato muri/porte/oggetti sulla griglia.
        ///
        /// Motivazione:
        /// - il World viene costruito prima del seeding (SimulationHost), quindi in ctor
        ///   non abbiamo ancora la geometria completa.
        /// </summary>
        public void RebuildLandmarksBootstrap()
        {
            LandmarkRegistry?.RebuildFromWorld(this);
        }

        // ============================================================
        // DEVTOOLS / RUNTIME DEVELOPER MODE (DevMode v0 - MVP)
        // ============================================================
        //
        // Documento di riferimento:
        // - "ARCONTIO - Runtime Developer Mode (DevTools).html"
        // - DevMode v0 richiede: place/erase oggetti + rebuild globale cache + save/load JSON. fileciteturn4file9
        //
        // IMPORTANTE (architettura):
        // - Queste API NON sono "gameplay". Sono strumenti di debug.
        // - Sono chiamate da comandi devtools (ICommand) eseguiti tramite SimulationHost.
        // - La View non deve mutare direttamente il World.

        /// <summary>
        /// RebuildDerivedCachesGlobal (DevMode v0 - MVP):
        /// ricostruisce TUTTE le cache derivate dal World.
        ///
        /// Perché esiste:
        /// - In questo progetto abbiamo cache derivate (OcclusionMap, bool[] blocks, LandmarkRegistry, ecc.)
        /// - In gameplay normale, queste cache vengono mantenute incrementalmente.
        /// - In DevMode v0 (MVP) vogliamo un comportamento semplice e robusto:
        ///   "dopo ogni edit, rifaccio tutto" per evitare bug di incoerenza.
        ///
        /// Nota performance:
        /// - Questo è volutamente O(nCells + nObjects).
        /// - Va benissimo per mappe piccole di debug.
        /// - In DevMode v1/v2 potremo ottimizzare (rebuild parziale / brush continuo / ecc.).
        /// </summary>
        public void RebuildDerivedCachesGlobal()
        {
            RebuildOcclusionCacheGlobal();

            // Landmark registry è anch'esso derivato dalla geometria mappa.
            // Nota: questa chiamata è safe se LandmarkRegistry è null.
            LandmarkRegistry?.RebuildFromWorld(this);
        }

        /// <summary>
        /// Ricostruisce da zero la cache occlusione + bool blocks + indice 1 object per cell.
        /// </summary>
        private void RebuildOcclusionCacheGlobal()
        {
            // Difensivo: se array non inizializzati, non facciamo nulla.
            if (_occlusion == null || _occlusion.Length != MapWidth * MapHeight) return;

            // 1) reset completo
            Array.Clear(_occlusion, 0, _occlusion.Length);

            if (_blocksVision != null && _blocksVision.Length == MapWidth * MapHeight)
                Array.Clear(_blocksVision, 0, _blocksVision.Length);

            if (_blocksMovement != null && _blocksMovement.Length == MapWidth * MapHeight)
                Array.Clear(_blocksMovement, 0, _blocksMovement.Length);

            // 2) reset indice "1 object per cell"
            if (_objIdByCell != null && _objIdByCell.Length == MapWidth * MapHeight)
            {
                for (int i = 0; i < _objIdByCell.Length; i++)
                    _objIdByCell[i] = -1;
            }

            // 3) reset componente runtime occluder: verrà ricostruito da PlaceOccluderInCache.
            // Nota:
            // - ObjectOccluders contiene anche occluder "runtime" (es. _runtime_occluder).
            // - In dev rebuild totale, la ricostruiamo da zero in modo coerente.
            ObjectOccluders.Clear();

            // 4) reinseriamo ogni oggetto:
            // - settiamo l'indice cella -> objectId
            // - se l'oggetto ha flags di occlusione, ricreiamo cache occlusion + bool[].
            foreach (var kv in Objects)
            {
                int objectId = kv.Key;
                var obj = kv.Value;
                if (obj == null) continue;

                int x = obj.CellX;
                int y = obj.CellY;

                if (!InBounds(x, y)) continue;

                if (_objIdByCell != null && _objIdByCell.Length == MapWidth * MapHeight)
                    _objIdByCell[CellIndex(x, y)] = objectId;

                if (!TryGetObjectDef(obj.DefId, out var def) || def == null) continue;

                if (def.IsOccluder || def.BlocksVision || def.BlocksMovement)
                    PlaceOccluderInCache(objectId, x, y, def);
            }
        }

        /// <summary>
        /// Esporta lo stato "editabile" dal DevMode in un DevMapData.
        ///
        /// Policy v0:
        /// - includiamo SOLO Objects (non NPC).
        /// - escludiamo il defId interno "_runtime_occluder" (tool legacy).
        /// </summary>
        public DevMapData ExportDevMapData()
        {
            var data = new DevMapData
            {
                Width = MapWidth,
                Height = MapHeight,
                Note = $"exported_at_tick_{TickContext.CurrentTickIndex}"
            };

            foreach (var kv in Objects)
            {
                var obj = kv.Value;
                if (obj == null) continue;

                // Filtriamo la def "interna" (non vogliamo salvarla in mappe di test).
                if (string.Equals(obj.DefId, "_runtime_occluder", StringComparison.OrdinalIgnoreCase))
                    continue;

                data.Objects.Add(new DevMapObject
                {
                    DefId = obj.DefId,
                    X = obj.CellX,
                    Y = obj.CellY,
                    OwnerKind = obj.OwnerKind.ToString(),
                    OwnerId = obj.OwnerId,
                });
            }

            return data;
        }

        /// <summary>
        /// Importa un DevMapData nel World.
        ///
        /// Policy v0:
        /// - clearObjects=true (default): sostituisce completamente il layout oggetti corrente.
        ///
        /// Nota:
        /// - Non tocchiamo NPC, memorie, needs, ecc. (dev mode v1+).
        /// - Se la mappa importata ha dimensioni diverse, NON ridimensioniamo la griglia:
        ///   logghiamo e comunque proviamo a piazzare ciò che entra in bounds.
        /// </summary>
        public void ImportDevMapData(DevMapData data, bool clearObjects = true)
        {
            if (data == null) return;

            if (data.Width != MapWidth || data.Height != MapHeight)
            {
                Debug.LogWarning($"[DevTools] ImportDevMapData: size mismatch. file=({data.Width}x{data.Height}) world=({MapWidth}x{MapHeight}). " +
                                 $"We will import only objects that fit in bounds.");
            }

            if (clearObjects)
            {
                // Snapshot: DestroyObject muta il dizionario.
                var ids = new List<int>(Objects.Keys);
                for (int i = 0; i < ids.Count; i++)
                    DestroyObject(ids[i]);
            }

            if (data.Objects == null) return;

            for (int i = 0; i < data.Objects.Count; i++)
            {
                var o = data.Objects[i];
                if (o == null) continue;
                if (string.IsNullOrWhiteSpace(o.DefId)) continue;
                if (!InBounds(o.X, o.Y)) continue;

                // Se in cella esiste qualcosa, lo rimpiazziamo: è un import "autoritative".
                int existing = GetObjectAt(o.X, o.Y);
                if (existing >= 0)
                    DestroyObject(existing);

                // OwnerKind parsing (difensivo)
                OwnerKind kind = OwnerKind.None;
                if (!string.IsNullOrWhiteSpace(o.OwnerKind))
                {
                    try { kind = (OwnerKind)Enum.Parse(typeof(OwnerKind), o.OwnerKind, ignoreCase: true); }
                    catch { kind = OwnerKind.None; }
                }

                CreateObject(o.DefId, o.X, o.Y, kind, o.OwnerId);
            }
        }
        


        // ============================================================
        // HELPERS: bounds + cell index
        // ============================================================
        private int Idx(int x, int y) => (y * MapWidth) + x;

        public bool InBounds(int x, int y)
            => x >= 0 && y >= 0 && x < MapWidth && y < MapHeight;

        private int CellIndex(int x, int y) => (y * MapWidth) + x;

        public int GetObjectAt(int x, int y)
        {
            if (!InBounds(x, y)) return -1;
            return _objIdByCell[CellIndex(x, y)];
        }


        // ============================================================
        // LANDMARK MEMORY HELPERS (v0.02 Day3)
        // ============================================================
        /// <summary>
        /// EnsureNpcLandmarkMemory:
        /// crea (se mancante) lo store di memoria landmark per questo NPC.
        ///
        /// Nota:
        /// - La memoria landmark � una cache soggettiva: non � obbligatorio averla quando
        ///   il sistema landmark � disabilitato.
        /// - Tuttavia � estremamente utile creare lo store al momento della creazione dell'NPC
        ///   per evitare allocazioni in momenti imprevedibili (es. durante un tick di movimento).
        /// </summary>
        public NpcLandmarkMemory EnsureNpcLandmarkMemory(int npcId)
        {
            if (!NpcLandmarkMemory.TryGetValue(npcId, out var mem) || mem == null)
            {
                mem = new NpcLandmarkMemory(maxLandmarks: Global.MaxLandmarksPerNpc, maxEdges: Global.MaxEdgesPerNpc);
                NpcLandmarkMemory[npcId] = mem;
            }
            return mem;
        }

        /// <summary>
        /// NotifyNpcMovedForLandmarkLearning (Day3):
        /// apprendimento event-driven agganciato al movimento.
        ///
        /// Contratto: viene chiamato SOLO quando l'NPC ha effettivamente cambiato cella.
        ///
        /// Cosa fa (baseline Day3):
        /// - se la cella di arrivo � un landmark attivo nel registry (Doorway/Junction), lo "impara"
        /// - se prima era stato visto un altro landmark, prova a "imparare" anche l'edge tra i due
        ///   (solo se esiste nel registry oggettivo: edge bootstrap Day2)
        ///
        /// Importante:
        /// - non facciamo scanning globale
        /// - non facciamo pathfinding qui
        /// - qui aggiorniamo SOLO la memoria soggettiva e i contatori debug
        /// </summary>
        public void NotifyNpcMovedForLandmarkLearning(int npcId, int fromX, int fromY, int toX, int toY)
        {
            // Se il sistema landmarks � disabilitato, non impariamo nulla.
            if (!Global.EnableLandmarkSystem)
                return;

            if (LandmarkRegistry == null)
                return;

            // Se l'NPC non esiste, abort.
            if (!NpcCore.ContainsKey(npcId))
                return;

            // Day3: impariamo SOLO se la cella di arrivo � un nodo landmark.
            if (!LandmarkRegistry.TryGetActiveNodeIdAtCell(toX, toY, out int nodeId))
                return;

            long now = TickContext.CurrentTickIndex;

            var mem = EnsureNpcLandmarkMemory(npcId);

            // Learn node (anti-thrashing gestito dentro NpcLandmarkMemory)
            mem.LearnLandmark(nodeId, now, evictionCooldownTicks: Global.LandmarkEvictionCooldownTicks);

            // Learn edge: se abbiamo un last landmark diverso
            int prev = mem.LastVisitedLandmarkId;
            if (prev != 0 && prev != nodeId)
            {
                if (LandmarkRegistry.TryGetActiveEdgeCostCells(prev, nodeId, out int costCells))
                {
                    mem.LearnEdge(prev, nodeId, costCells, now, evictionCooldownTicks: Global.LandmarkEvictionCooldownTicks);
                }
            }

            // Aggiorniamo sempre l'ultimo landmark visitato quando ne vediamo uno.
            mem.LastVisitedLandmarkId = nodeId;
        }

// ============================================================
        // LANDMARK DEBUG (v0.02 Day1)
        // ============================================================
        /// <summary>
        /// Debug report stampabile per NPC.
        ///
        /// Roadmap Day1:
        /// - deve funzionare anche se il sistema landmark è disabilitato o non implementato.
        /// - quindi: ritorniamo valori coerenti (zeri) e NON facciamo mai throw.
        ///
        /// Nota:
        /// - Quando introdurremo LandmarkMemory/Graph per NPC (Day3+), questo metodo diventerà
        ///   la query unica (view-safe) per esporre contatori.
        /// </summary>
        public bool TryGetNpcLandmarkDebugReport(int npcId, out NpcLandmarkDebugReport report)
        {
            // Day1/Day2: non esiste ancora il grafo soggettivo per NPC.
            // Tuttavia:
            // - Day1: micro-test fittizio per validare overlay.
            // - Day2: registry oggettivo (World-side) che possiamo già contare/mostrare.

            bool npcExists = NpcCore.ContainsKey(npcId);
            if (!npcExists)
            {
                report = default;
                return false;
            }

            var dbg = Config?.Sim?.landmarks?.debug;
            bool microTestEnabled = dbg != null && dbg.enabled && dbg.microTestDummyGraph;

            if (microTestEnabled)
            {
                // Report coerente con il grafo dummy generato in GetNpcLandmarkOverlayData().
                report = new NpcLandmarkDebugReport(
                    knownLandmarksCount: 2,
                    knownEdgesCount: 1,
                    poiAnchorCount: 0,
                    replansPerMin: 0f,
                    failuresPerMin: 0f,
                    blacklistSize: 0);
                return true;
            }

            // Day3: contatori soggettivi.
            // Importante:
            // - NON esponiamo più i contatori oggettivi del registry come 'known' dell'NPC.
            // - se l'NPC non ha ancora imparato nulla, i contatori restano 0.
            //
            // Nota:
            // - In debug può essere utile vedere anche i contatori del registry (World-side),
            //   ma quelli appartengono a un'altra query (non questa).
            int lmCount = 0;
            int eCount = 0;

            if (NpcLandmarkMemory.TryGetValue(npcId, out var mem) && mem != null)
            {
                lmCount = mem.KnownLandmarksCount;
                eCount = mem.KnownEdgesCount;
            }

            report = new NpcLandmarkDebugReport(
                knownLandmarksCount: lmCount,
                knownEdgesCount: eCount,
                poiAnchorCount: 0,
                replansPerMin: 0f,
                failuresPerMin: 0f,
                blacklistSize: 0);

            return true;
        }

        /// <summary>
        /// Overlay data (nodi + edges) per un singolo NPC, separato in due layer:
        ///
        /// - WORLD: tutti i landmark/edge oggettivi del registry.
        /// - KNOWN: subset soggettivo conosciuto dall'NPC.
        ///
        /// Motivazione della modifica:
        /// - In debug vogliamo vedere SEMPRE il grafo del mondo.
        /// - Sopra a quel grafo vogliamo anche vedere, in colore diverso, cio' che l'NPC ha imparato.
        /// - Non vogliamo piu' il comportamento "world oppure memory": i due layer devono convivere.
        ///
        /// Nota:
        /// - Non introduciamo nuovi parametri JSON: e' una scelta hardcoded di debug/UX.
        /// </summary>
        public void GetNpcLandmarkOverlayData(
            int npcId,
            System.Collections.Generic.List<LandmarkOverlayNode> outWorldNodes,
            System.Collections.Generic.List<LandmarkOverlayEdge> outWorldEdges,
            System.Collections.Generic.List<LandmarkOverlayNode> outKnownNodes,
            System.Collections.Generic.List<LandmarkOverlayEdge> outKnownEdges)
        {
            if (outWorldNodes != null) outWorldNodes.Clear();
            if (outWorldEdges != null) outWorldEdges.Clear();
            if (outKnownNodes != null) outKnownNodes.Clear();
            if (outKnownEdges != null) outKnownEdges.Clear();

            // Se l'NPC non esiste, non c'e' nulla da disegnare.
            if (!NpcCore.ContainsKey(npcId)) return;

            // ---------------- MICRO-TEST (Day1) ----------------
            // Manteniamo il comportamento storico sul layer WORLD.
            // Il layer KNOWN resta vuoto, perche' il micro-test serve solo a verificare il rendering.
            var dbg = Config?.Sim?.landmarks?.debug;
            bool microTestEnabled = dbg != null && dbg.enabled && dbg.microTestDummyGraph;

            if (microTestEnabled)
            {
                if (GridPos.TryGetValue(npcId, out var gp))
                {
                    int dx = Mathf.Max(1, dbg.microTestDummyDistanceCells);

                    int ax = Mathf.Clamp(gp.X, 0, MapWidth - 1);
                    int ay = Mathf.Clamp(gp.Y, 0, MapHeight - 1);

                    int bx = Mathf.Clamp(ax + dx, 0, MapWidth - 1);
                    int by = ay;

                    if (bx == ax)
                        bx = Mathf.Clamp(ax - dx, 0, MapWidth - 1);

                    outWorldNodes?.Add(new LandmarkOverlayNode(cellX: ax, cellY: ay, kind: 0));
                    outWorldNodes?.Add(new LandmarkOverlayNode(cellX: bx, cellY: by, kind: 0));
                    outWorldEdges?.Add(new LandmarkOverlayEdge(ax: ax, ay: ay, bx: bx, by: by, reliability01: 1f));
                }
                return;
            }

            // ---------------- WORLD LAYER ----------------
            LandmarkRegistry?.FillOverlayData(outWorldNodes, outWorldEdges);

            // ---------------- KNOWN LAYER ----------------
            if (NpcLandmarkMemory.TryGetValue(npcId, out var mem) && mem != null)
            {
                mem.FillOverlayData(LandmarkRegistry, outKnownNodes, outKnownEdges);
            }
        }
// ============================================================
        // INVENTORY HELPERS


        /// <summary>
        /// SetFoodStock (Patch 5.1):
        /// Punto unico (best practice) per scrivere/aggiornare FoodStocks.
        ///
        /// Perché esiste:
        /// - Evita "footgun" dove qualcuno fa FoodStocks[objId]=... senza aggiornare altri sistemi.
        /// - Qui aggiorniamo anche il pinned belief (NpcPinnedFoodStockBeliefs) quando appropriato.
        ///
        /// IMPORTANTISSIMO (revised policy):
        /// - Aggiorniamo il pinned belief SOLO in ingresso (creazione/posizionamento conosciuto dall'NPC).
        /// - NON cancelliamo il pinned belief automaticamente su furto/distruzione offscreen:
        ///   la cancellazione avviene solo quando l'NPC ispeziona e constata l'assenza.
        /// </summary>
        public void SetFoodStock(int objectId, FoodStockComponent stock)
        {
            // Scrittura del componente oggettivo (fact).
            FoodStocks[objectId] = stock;

            // Se lo stock è privato di un NPC, aggiungiamo (o aggiorniamo) la belief pinned.
            // Nota: questo non significa che l'NPC lo "vede ora", significa che lo stock è stato
            // creato/assegnato a lui in un punto del gameplay dove la conoscenza è implicita
            // (es. lo ha posato lui, lo ha ricevuto come proprietà).
            if (stock.OwnerKind == OwnerKind.Npc && stock.OwnerId != 0)
            {
                if (Objects.TryGetValue(objectId, out var obj) && obj != null)
                {
                    EnsurePinnedFoodStockBelief(stock.OwnerId, objectId, obj.CellX, obj.CellY);
                }
            }
        }

        /// <summary>
        /// EnsurePinnedFoodStockBelief:
        /// Inserisce il riferimento (objectId + lastKnown cell) nella lista belief dell'NPC.
        /// Se già presente, aggiorna la posizione (utile quando lo stock viene posato/spostato
        /// tramite azione dell'NPC proprietario).
        /// </summary>
        public void EnsurePinnedFoodStockBelief(int npcId, int objectId, int lastKnownX, int lastKnownY)
        {
            if (npcId == 0 || objectId == 0)
                return;

            if (!NpcPinnedFoodStockBeliefs.TryGetValue(npcId, out var list) || list == null)
            {
                list = new List<PinnedFoodStockBelief>(capacity: 4);
                NpcPinnedFoodStockBeliefs[npcId] = list;
            }

            // Update in-place se già esiste.
            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].ObjectId == objectId)
                {
                    var e = list[i];
                    e.LastKnownX = lastKnownX;
                    e.LastKnownY = lastKnownY;
                    list[i] = e;
                    return;
                }
            }

            // Altrimenti aggiungiamo una nuova belief entry.
            list.Add(new PinnedFoodStockBelief
            {
                ObjectId = objectId,
                LastKnownX = lastKnownX,
                LastKnownY = lastKnownY
            });
        }

        /// <summary>
        /// RemovePinnedFoodStockBelief:
        /// Rimuove una belief entry.
        ///
        /// POLICY:
        /// - Questa chiamata va usata quando l'NPC *scopre* che lo stock non è dove si aspettava
        ///   (es. arriva sul posto e non lo trova), oppure quando ha un'informazione "valida"
        ///   (in futuro: comunicazione, witness, ecc.).
        /// </summary>
        public void RemovePinnedFoodStockBelief(int npcId, int objectId)
        {
            if (npcId == 0 || objectId == 0)
                return;

            if (!NpcPinnedFoodStockBeliefs.TryGetValue(npcId, out var list) || list == null)
                return;

            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].ObjectId == objectId)
                {
                    list.RemoveAt(i);
                    break;
                }
            }

            // Cleanup: se vuota, rimuoviamo la chiave per evitare dizionari gonfi.
            if (list.Count == 0)
                NpcPinnedFoodStockBeliefs.Remove(npcId);
        }

        // ============================================================
        //
        // Obiettivo:
        // - centralizzare la logica di capienza dell'inventario dell'NPC
        // - evitare duplicazioni in Rule/System/CommandHandler
        //
        // Nota:
        // - Oggi contiamo solo NpcPrivateFood (unità di cibo portate addosso).
        // - In futuro, quando introdurremo altri oggetti trasportati, questo metodo
        //   dovrà includere anche quelle collezioni (es: NpcCarriedItems, ecc.).
        // - Importante: il World è "source of truth" dello stato globale; la view legge soltanto.

        /// <summary>
        /// Capienza massima dell'inventario di questo NPC (in unità).
        ///
        /// Oggi è globale (uguale per tutti gli NPC).
        /// In futuro potremo introdurre override per archetipo/ruolo.
        /// </summary>
        public int GetInventoryMaxUnits(int npcId)
        {
            // npcId non è ancora usato (perché la capienza è globale),
            // ma lo teniamo per compatibilità futura con override per archetipo.
            return Global.InventoryMaxUnits;
        }

        /// <summary>
        /// Unità già occupate nell'inventario dell'NPC.
        ///
        /// ATTUALE:
        /// - cibo privato trasportato (NpcPrivateFood)
        ///
        /// FUTURO:
        /// - altri oggetti trasportati da aggiungere qui.
        /// </summary>
        public int GetInventoryUsedUnits(int npcId)
        {
            // Food carried (private).
            NpcPrivateFood.TryGetValue(npcId, out int food);
            if (food < 0) food = 0;

            // TODO (futuro): sommare altre categorie di item carried.
            // Esempio:
            // int other = NpcCarriedItems.TryGetValue(npcId, out var list) ? list.Count : 0;

            return food;
        }

        /// <summary>
        /// Quante unità libere restano nell'inventario dell'NPC.
        /// </summary>
        public int GetInventoryFreeCapacity(int npcId)
        {
            int max = GetInventoryMaxUnits(npcId);
            int used = GetInventoryUsedUnits(npcId);

            int free = max - used;
            if (free < 0) free = 0;
            return free;
        }


        // ============================================================
        // NPC API
        // ============================================================

        public bool ExistsNpc(int npcId) => npcId > 0 && NpcCore.ContainsKey(npcId);
        public bool AreBonded(int aNpcId, int bNpcId)
        {
            // STUB (roadmap): quando introdurrai bond graph,
            // questa funzione consulterà quel grafo.
            return false;
        }

        public int CreateNpc(NpcCore core, Needs needs, Social social, int x, int y)
        {
            int id = _nextNpcId++;

            NpcCore[id] = core;
            Needs[id] = needs;
            Social[id] = social;
            GridPos[id] = new GridPosition(x, y);
            NpcFacing[id] = CardinalDirection.North;

            // Memory params
            if (!MemoryParams.ContainsKey(id))
                MemoryParams[id] = PersonalityMemoryParams.DefaultNpc();

            // MemoryStore: NON ha costruttore con maxTraces.
            // Imposti MaxTraces dopo la creazione.
            var store = new MemoryStore();

            // Priorità: se hai un config globale, usalo; altrimenti fallback su PersonalityMemoryParams.
            int maxTraces = MemoryParams[id].MaxTraces;
            if (Global.NpcObjectMemorySlots > 0) { /* non è maxTraces: è slots oggetti (altro). */ }

            store.MaxTraces = maxTraces;
            Memory[id] = store;

            // Private food init (se non presente)
            if (!NpcPrivateFood.ContainsKey(id))
                NpcPrivateFood[id] = 0;

            // Tick consumo privato
            if (!NpcLastPrivateFoodConsumeTick.ContainsKey(id))
                NpcLastPrivateFoodConsumeTick[id] = -999999;

            // Movement intent init (se non presente)
            if (!NpcMoveIntents.ContainsKey(id))
                NpcMoveIntents[id] = default;

            // Scan state init (se non presente)
            if (!NpcScanStates.ContainsKey(id))
                NpcScanStates[id] = default;


            // ============================================================
            // Landmark memory init (v0.02 Day3)
            // ============================================================
            //
            // Importante:
            // - La memoria landmark e una cache soggettiva e viene popolata event-driven durante il movimento.
            // - Creiamo lo store qui per evitare allocazioni durante i tick e per garantire che
            //   ogni NPC abbia un contenitore pronto (anche se all'inizio e vuoto).
            //
            // Nota:
            // - Se il sistema landmarks e disabilitato, non e dannoso avere lo store (vuoto).
            EnsureNpcLandmarkMemory(id);


// Action state init (se non presente)
if (!NpcAction.ContainsKey(id))
    NpcAction[id] = NpcActionState.Idle();

            // Balloon signal init (se non presente)
            // Nota:
            // - Default = struct default => Kind=None, Tick=0.
            // - La view userà il tick per capire se ha già mostrato il balloon.
            if (!NpcBalloonSignals.ContainsKey(id))
                NpcBalloonSignals[id] = default;
            return id;
        }

        public void SetFacing(int npcId, CardinalDirection dir)
        {
            if (!ExistsNpc(npcId)) return;
            NpcFacing[npcId] = dir;
        }

        // ============================================================
        // Facing / Position / Movement helper API
        // ============================================================

        /// <summary>
        /// GetFacing:
        /// - Non esisteva come helper; è utile per sistemi (scan, movement) e debug.
        /// - Se manca entry, default = North (deterministico).
        /// </summary>
        public CardinalDirection GetFacing(int npcId)
        {
            if (!ExistsNpc(npcId)) return CardinalDirection.North;
            if (NpcFacing.TryGetValue(npcId, out var dir)) return dir;
            return CardinalDirection.North;
        }

        /// <summary>
        /// TryGetNpcPos:
        /// - Fonte di verità runtime per la posizione NPC è GridPos.
        /// </summary>
        public bool TryGetNpcPos(int npcId, out int x, out int y)
        {
            x = 0; y = 0;
            if (!GridPos.TryGetValue(npcId, out var gp)) return false;
            x = gp.X; y = gp.Y;
            return true;
        }

        /// <summary>
        /// SetNpcPos:
        /// - Aggiorna GridPos.
        /// - In futuro questo è il punto perfetto per pubblicare NpcMovedEvent / PerceptionDirty.
        /// </summary>
        public void SetNpcPos(int npcId, int x, int y)
        {
            if (!ExistsNpc(npcId)) return;
            GridPos[npcId] = new GridPosition(x, y);
        }

        public bool TryGetObjectCell(int objectId, out int x, out int y)
        {
            x = 0; y = 0;
            if (!Objects.TryGetValue(objectId, out var obj) || obj == null) return false;
            x = obj.CellX; y = obj.CellY;
            return true;
        }

        public bool BlocksMovementAt(int x, int y)
        {
            if (!TryGetOccluder(x, y, out _, out bool bm, out _)) return false;
            return bm;
        }

        /// <summary>
        /// O(N) per DAY10 (pochi NPC). In futuro cache.
        /// </summary>
        public bool TryGetNpcAt(int x, int y, out int npcId)
        {
            npcId = 0;
            foreach (var kv in GridPos)
            {
                if (kv.Value.X == x && kv.Value.Y == y)
                {
                    npcId = kv.Key;
                    return true;
                }
            }
            return false;
        }

        public void SetMoveIntent(int npcId, MoveIntent intent)
        {
            if (!ExistsNpc(npcId)) return;

            NpcMoveIntents[npcId] = intent;
        }

        public void ClearMoveIntent(int npcId)
        {
            if (!ExistsNpc(npcId)) return;
            NpcMoveIntents[npcId] = default;
        }
        

        // ============================================================
        // NPC ACTION STATE (API)
        // ============================================================

        /// <summary>
        /// Imposta lo stato di azione dell'NPC.
        /// 
        /// Nota:
        /// - Non validiamo "consistenza semantica" qui (es: puoi dire Eat anche se non c'è cibo).
        /// - Questo è volutamente un canale descrittivo/diagnostico.
        /// - Le guardie sono solo su ExistsNpc.
        /// </summary>
        public void SetNpcAction(int npcId, NpcActionState state)
        {
            if (!ExistsNpc(npcId)) return;
            NpcAction[npcId] = state;
        }

        /// <summary>
        /// Utility: imposta l'NPC in stato Idle (azione "nessuna"/default).
        /// </summary>
        public void SetNpcIdle(int npcId)
        {
            if (!ExistsNpc(npcId)) return;
            NpcAction[npcId] = NpcActionState.Idle();
        }

        /// <summary>
        /// Prova a leggere lo stato di azione corrente.
        /// </summary>
        public bool TryGetNpcAction(int npcId, out NpcActionState state)
        {
            if (!ExistsNpc(npcId))
            {
                state = default;
                return false;
            }
            return NpcAction.TryGetValue(npcId, out state);
        }


        // ============================================================
        // NPC BALLOON SIGNAL (API)
        // ============================================================

        /// <summary>
        /// Imposta l'ultimo balloon signal per un NPC.
        ///
        /// Nota:
        /// - È un segnale transiente: la view lo consumerà mostrando un balloon per X secondi.
        /// - NON è un bus di eventi.
        /// - Non validiamo semantica qui: è solo osservabilità.
        /// </summary>
        public void SetNpcBalloonSignal(int npcId, NpcBalloonSignal signal)
        {
            if (!ExistsNpc(npcId)) return;
            NpcBalloonSignals[npcId] = signal;
        }

        /// <summary>
        /// Convenience: emette un balloon con tick corrente (TickContext).
        /// </summary>
        public void EmitNpcBalloon(int npcId, NpcBalloonKind kind, int subjectId = 0, int secondarySubjectId = 0)
        {
            if (!ExistsNpc(npcId)) return;

            int tick = (int)TickContext.CurrentTickIndex;
            NpcBalloonSignals[npcId] = new NpcBalloonSignal
            {
                Kind = kind,
                Tick = tick,
                SubjectId = subjectId,
                SecondarySubjectId = secondarySubjectId
            };
        }

        public bool TryGetNpcBalloonSignal(int npcId, out NpcBalloonSignal signal)
        {
            if (!ExistsNpc(npcId))
            {
                signal = default;
                return false;
            }
            return NpcBalloonSignals.TryGetValue(npcId, out signal);
        }


        /// <summary>
        /// Utility: consideriamo "idle" se non ha MoveIntent attivo e non sta facendo scan.
        /// Questo è volutamente minimale: in futuro ActivityStateComponent può sostituire.
        /// </summary>
        public bool IsNpcIdleForScan(int npcId)
        {
            if (!ExistsNpc(npcId)) return false;

            if (NpcMoveIntents.TryGetValue(npcId, out var mi) && mi.Active)
                return false;

            if (NpcScanStates.TryGetValue(npcId, out var ss) && ss.Active)
                return false;

            return true;
        }

        public void StartScan(int npcId, int currentTick, int turns = 4)
        {
            if (!ExistsNpc(npcId)) return;

            // Importante:
            // - lo scan è "costoso": è una sequenza di turn su tick successivi.
            // - non facciamo 4 turn nello stesso tick.
            NpcScanStates[npcId] = new ScanState
            {
                Active = true,
                RemainingTurns = turns,
                LastTurnTick = currentTick - 999999
            };
        }

        public void StopScan(int npcId)
        {
            if (!ExistsNpc(npcId)) return;
            NpcScanStates[npcId] = default;
        }


        // ============================================================
        // OBJECT API (Create / Destroy)
        // ============================================================

        public int CreateObject(string defId, int x, int y, OwnerKind ownerKind = OwnerKind.None, int ownerId = -1)
        {
            if (string.IsNullOrWhiteSpace(defId))
                return -1;

            if (!ObjectDefs.ContainsKey(defId))
            {
                Debug.LogWarning($"[World] CreateObject failed: unknown defId='{defId}'");
                return -1;
            }

            if (MapWidth > 0 && MapHeight > 0 && !InBounds(x, y))
            {
                Debug.LogWarning($"[World] CreateObject failed: out of bounds ({x},{y})");
                return -1;
            }

            if (HasAnyObjectAt(x, y))
            {
                Debug.LogWarning($"[World] CreateObject failed: cell occupied ({x},{y}) (1 object per cell)");
                return -1;
            }

            int id = _nextObjectId++;

            var inst = new WorldObjectInstance
            {
                ObjectId = id,
                DefId = defId,
                CellX = x,
                CellY = y,
                OwnerKind = ownerKind,
                OwnerId = ownerId,
                OccupantNpcId = -1
            };

            Objects[id] = inst;

            // Se è un occluder oppure blocca la visione o il movimento, aggiorna la occlusion map.
            if (TryGetObjectDef(defId, out var def) && def != null &&
                               (def.IsOccluder || def.BlocksVision || def.BlocksMovement))
            {
                PlaceOccluderInCache(id, x, y, def);
            }

            return id;
        }

        public void DestroyObject(int objectId)
        {
            if (!Objects.TryGetValue(objectId, out var obj) || obj == null)
                return;

            int x = obj.CellX;
            int y = obj.CellY;

            // 1) Se è occluder, pulisci la cache occlusione prima di rimuovere dai dizionari.
            //    (Questo evita che restino celle "bloccate" anche dopo la rimozione dell'oggetto.)
            if (TryGetObjectDef(obj.DefId, out var def) && def != null && def.IsOccluder)
            {
                ClearOccluderFromCache(objectId, x, y);

                // Difensivo: nel tuo file coesistono due cache (OcclusionCell[] e bool[]).
                // HasLineOfSight usa _occlusion, ma alcune API (IsVisionBlocked/IsMovementBlocked) usano bool[].
                // Quindi, se questi array esistono, azzeriamo anche loro.
                if (_blocksVision != null && _blocksVision.Length == MapWidth * MapHeight && InBounds(x, y))
                    _blocksVision[CellIndex(x, y)] = false;

                if (_blocksMovement != null && _blocksMovement.Length == MapWidth * MapHeight && InBounds(x, y))
                    _blocksMovement[CellIndex(x, y)] = false;
            }

            // 2) Libera la cella nella griglia "1 object per cell".
            //    Nel tuo World l'empty value è -1 (come da commento su _objIdByCell).
            if (_objIdByCell != null && _objIdByCell.Length == MapWidth * MapHeight && InBounds(x, y))
            {
                int idx = CellIndex(x, y);

                // Difensivo: liberiamo solo se la cella punta davvero a quell'objectId.
                if (_objIdByCell[idx] == objectId)
                    _objIdByCell[idx] = -1;
            }

            // 3) component cleanup (use state, stocks, runtime occluders)
            //
            // IMPORTANTISSIMO (Patch 5.1 - revised):
            // - Qui rimuoviamo i componenti OGGETTIVI (facts) associati all'objectId.
            // - NON tocchiamo il pinned belief degli NPC (NpcPinnedFoodStockBeliefs):
   
            //   se lo stock viene distrutto/rubato fuori dalla loro percezione, loro NON devono
            //   essere aggiornati automaticamente. Scopriranno la perdita solo ispezionando.
            ObjectUse.Remove(objectId);
            FoodStocks.Remove(objectId);
            ObjectOccluders.Remove(objectId);

            // 4) rimuovi dal registry oggetti
            Objects.Remove(objectId);
        }

        private void PlaceOccluderInCache(int objectId, int x, int y, ObjectDef def)
        {
            if (_occlusion == null || _occlusion.Length == 0) return;
            if (!InBounds(x, y)) return;

            int idx = Idx(x, y);

            // Se già presente qualcosa, lo consideriamo errore di coerenza (1 occluder per cell).
            if (_occlusion[idx].OccluderObjectId != 0 && _occlusion[idx].OccluderObjectId != objectId)
            {
                Debug.LogWarning($"[World] OcclusionMap overwrite at ({x},{y}). old={_occlusion[idx].OccluderObjectId} new={objectId}");
            }

		            // ------------------------------------------------------------
            // IMPORTANTISSIMO (bugfix):
            // In questo World coesistono due cache:
            // - _occlusion[] (OcclusionCell) usata da HasLineOfSight / TryGetOccluder
            // - _blocksVision[] / _blocksMovement[] usate da IsVisionBlocked / IsMovementBlocked
            //
            // CreateObject() aggiorna l'occlusione via PlaceOccluderInCache.
            // Se qui non aggiorniamo anche i bool[], IsMovementBlocked può restare "false"
            // su celle muro => un NPC può finire dentro una cella wall.
            // ------------------------------------------------------------

            bool blocksVision = def.BlocksVision;
            bool blocksMove = def.BlocksMovement;

            // Se è marcato come occluder ma non ha flags, default "blocca tutto".
            if (def.IsOccluder && !blocksVision && !blocksMove)
            {
                blocksVision = true;
                blocksMove = true;
            }
			
            _occlusion[idx] = new OcclusionCell
            {
                OccluderObjectId = objectId,
                BlocksVision = def.BlocksVision,
                BlocksMovement = def.BlocksMovement,
                VisionCost = def.VisionCost <= 0f ? 1f : def.VisionCost
            };
			
			// Allinea le cache bool[] se esistono (difensivo).
            if (_blocksVision != null && _blocksVision.Length == MapWidth * MapHeight)
                _blocksVision[CellIndex(x, y)] = blocksVision;

            if (_blocksMovement != null && _blocksMovement.Length == MapWidth * MapHeight)
                _blocksMovement[CellIndex(x, y)] = blocksMove;

            // Manteniamo anche il componente runtime per query dettagliate (TryGetOccluder ecc.).
            ObjectOccluders[objectId] = new Occluder
            {
                BlocksVision = blocksVision,
                BlocksMovement = blocksMove,
                VisionCost = def.VisionCost <= 0f ? 1f : def.VisionCost
            };	
        }

        private void ClearOccluderFromCache(int objectId, int x, int y)
        {
            if (_occlusion == null || _occlusion.Length == 0) return;
            if (!InBounds(x, y)) return;

            int idx = Idx(x, y);
            if (_occlusion[idx].OccluderObjectId == objectId)
                _occlusion[idx] = default;

            // Allinea le cache bool[] (difensivo).
            if (_blocksVision != null && _blocksVision.Length == MapWidth * MapHeight)
                _blocksVision[CellIndex(x, y)] = false;

            if (_blocksMovement != null && _blocksMovement.Length == MapWidth * MapHeight)
                _blocksMovement[CellIndex(x, y)] = false;

            // Il registry ObjectOccluders è per objectId.
            ObjectOccluders.Remove(objectId);
        }

        /// <summary>
        /// Regola ARCONTIO Core Standard v1.0: 1 object per cell.
        /// Qui facciamo enforcement minimo:
        /// - se esiste già un oggetto in (x,y) => fail.
        /// </summary>
        public bool HasAnyObjectAt(int x, int y)
        {
            foreach (var kv in Objects)
            {
                var o = kv.Value;
                if (o != null && o.CellX == x && o.CellY == y)
                    return true;
            }
            return false;
        }


        // ------------------------------------------------------------
        // Helpers
        // ------------------------------------------------------------
        public bool TryGetObjectDef(string defId, out ObjectDef def)
        {
            def = null;
            if (string.IsNullOrWhiteSpace(defId)) return false;
            return ObjectDefs.TryGetValue(defId, out def) && def != null;
        }

        public ObjectUseState GetUseStateOrDefault(int objId)
        {
            if (ObjectUse.TryGetValue(objId, out var s))
                return s;

            // default runtime = libero
            return ObjectUseState.Free();
        }

        public void SetUseState(int objId, ObjectUseState s)
        {
            ObjectUse[objId] = s;
        }

        // ============================================================
        // OCCLUSION MAP API (cache)
        // ============================================================

        public bool IsVisionBlocked(int x, int y)
        {
            if (!InBounds(x, y)) return true; // fuori mappa: trattalo come ?chiuso?
            return _blocksVision[CellIndex(x, y)];
        }

        public bool IsMovementBlocked(int x, int y)
        {
            if (!InBounds(x, y)) return true;
            return _blocksMovement[CellIndex(x, y)];
        }

        /// <summary>
        /// TryGetOccluder:
        /// - restituisce true se nella cella c'è un oggetto che blocca visione e/o movimento.
        /// - i dettagli stanno in ObjectOccluders (se presenti) altrimenti in def flags.
        /// </summary>
        public bool TryGetOccluder(int x, int y, out bool blocksVision, out bool blocksMovement, out float visionCost)
        {
            blocksVision = false;
            blocksMovement = false;
            visionCost = 0f;

            if (_occlusion == null || _occlusion.Length == 0) return false;
            if (!InBounds(x, y)) return false;

            var c = _occlusion[Idx(x, y)];
            if (c.OccluderObjectId == 0) return false;

            blocksVision = c.BlocksVision;
            blocksMovement = c.BlocksMovement;
            visionCost = c.VisionCost;
            return true;
        }
        public bool BlocksVisionAt(int x, int y)
        {
            if (!TryGetOccluder(x, y, out bool bv, out _, out _)) return false;
            return bv;
        }

        /// <summary>
        /// Wrapper legacy: SetOccluder(x,y,Occluder).
        ///
        /// Per non rompere i test/seed già scritti, questo:
        /// - crea (o aggiorna) un oggetto in quella cella con defId="_runtime_occluder"
        /// - lo mette in ObjectOccluders e aggiorna la cache.
        ///
        /// Migrazione consigliata:
        /// - sostituiscilo con CreateObject("wall_stone", x,y) ecc.
        /// </summary>
        public void SetOccluder(int x, int y, Occluder occ)
        {
            if (!InBounds(x, y)) return;

            // assicura una def runtime (se manca, la creiamo al volo)
            const string runtimeDef = "_runtime_occluder";
            if (!ObjectDefs.ContainsKey(runtimeDef))
            {
                ObjectDefs[runtimeDef] = new ObjectDef
                {
                    Id = runtimeDef,
                    DisplayName = "Runtime Occluder",
                    IsOccluder = true,
                    BlocksVision = true,
                    BlocksMovement = true,
                    VisionCost = 1f
                };
            }

            int existing = GetObjectAt(x, y);
            int objId;

            if (existing >= 0)
            {
                objId = existing;
                // se c?è un oggetto ?normale? già piazzato, qui sei in conflitto con 1 object/cell.
                // Per il debug: logghiamo e sovrascriviamo SOLO l?occlusione cache, senza cambiare l?oggetto.
                // Se vuoi muro ?vero?, devi piazzare l?oggetto muro e non un letto nella stessa cella.
                Debug.LogWarning($"[World] SetOccluder: cell ({x},{y}) already has obj={existing}. " +
                                 $"Keeping object, overriding occlusion cache only.");
            }
            else
            {
                objId = CreateObject(runtimeDef, x, y, OwnerKind.None, -1);
                if (objId < 0) return;
            }

            // store runtime occluder component
            ObjectOccluders[objId] = occ;

            // aggiorna cache cella
            int idx = CellIndex(x, y);
            _blocksVision[idx] = occ.BlocksVision;
            _blocksMovement[idx] = occ.BlocksMovement;
        }

        private void RebuildOcclusionCell(int x, int y)
        {
            if (!InBounds(x, y)) return;

            int objId = GetObjectAt(x, y);
            if (objId == 0 || !Objects.TryGetValue(objId, out var obj) || obj == null)
            {
                _occlusion[Idx(x, y)] = default;
                return;
            }

            if (!TryGetObjectDef(obj.DefId, out var def) || def == null)
            {
                _occlusion[Idx(x, y)] = default;
                return;
            }

            _occlusion[Idx(x, y)] = new OcclusionCell
            {
                BlocksVision = def.BlocksVision,
                BlocksMovement = def.BlocksMovement,
                VisionCost = def.VisionCost
            };
        }

        // ============================================================
        // LOS helpers (Bresenham)
        // ============================================================

        /// <summary>
        /// LOS discreta (grid) con Bresenham.
        /// Regola: se una cella intermedia ha BlocksVision=true => LOS bloccata.
        /// Nota: non controlliamo la cella sorgente; controlliamo le celle "attraversate".
        /// </summary>
        public bool HasLineOfSight(int sx, int sy, int tx, int ty)
        {
            if (_occlusion == null || _occlusion.Length == 0)
            {
                // Se non hai InitMap, non possiamo fare LOS su cache: fallback "true"
                return true;
            }

            if (!InBounds(sx, sy) || !InBounds(tx, ty))
                return false;

            int x0 = sx, y0 = sy;
            int x1 = tx, y1 = ty;

            int dx = Mathf.Abs(x1 - x0);
            int dy = Mathf.Abs(y1 - y0);
            int sxStep = x0 < x1 ? 1 : -1;
            int syStep = y0 < y1 ? 1 : -1;
            int err = dx - dy;

            // percorriamo la linea; saltiamo la prima cella (sorgente),
            // e consideriamo blocking sulle celle intermedie e target (in genere anche il target può essere muro).
            bool first = true;

            while (true)
            {
                if (!first)
                {
                    if (BlocksVisionAt(x0, y0))
                        return false;
                }
                first = false;

                if (x0 == x1 && y0 == y1)
                    break;

                int e2 = 2 * err;
                if (e2 > -dy) { err -= dy; x0 += sxStep; }
                if (e2 < dx) { err += dx; y0 += syStep; }
            }

            return true;
        }

        // ============================================================
        // INTERNAL: apply def occlusion on create
        // ============================================================

        private void ApplyDefOcclusionToCell(int objId, string defId, int x, int y)
        {
            if (!InBounds(x, y)) return;

            if (!ObjectDefs.TryGetValue(defId, out var def) || def == null)
                return;

            bool blocksVision = def.BlocksVision;
            bool blocksMove = def.BlocksMovement;

            // Se è marcato come occluder, ma non ha flags specifiche, default ?blocca tutto?
            if (def.IsOccluder)
            {
                if (!blocksVision && !blocksMove)
                {
                    blocksVision = true;
                    blocksMove = true;
                }
            }

            int idx = CellIndex(x, y);
            _blocksVision[idx] = blocksVision;
            _blocksMovement[idx] = blocksMove;

            // Se è un occluder ?vero?, registriamo anche il componente runtime per query dettagliate.
            if (def.IsOccluder || blocksVision || blocksMove)
            {
                ObjectOccluders[objId] = new Occluder
                {
                    BlocksVision = blocksVision,
                    BlocksMovement = blocksMove,
                    VisionCost = def.VisionCost <= 0f ? 1f : def.VisionCost
                };
            }
        }
    }

    /// <summary>
    /// Stato globale del mondo.
    /// </summary>
    public struct GlobalState
    {
        // --- Memory Spatial Fusion ---
        public bool EnableMemorySpatialFusion;
        public int MemoryRegionSizeCells;

        // --- Tokens ---
        public int MaxTokensPerEncounter;
        public int MaxTokensPerNpcPerDay;
        public int RepeatShareCooldownTicks;

        public int TokenDeliveryMaxRangeCells;
        public bool EnableTokenLOS;
        public float TokenReliabilityFalloffPerCell;
        public float TokenIntensityFalloffPerCell;

        // --- Perception base ---
        public int NpcOperationalRangeCells;
        public int NpcVisionRangeCells;
        public bool NpcVisionUseCone;
        public float NpcVisionConeSlope; // half-width per forward step (grid cone)
        public float NpcVisionConeHalfWidthPerStep; // legacy/back-compat (se lo stai usando altrove)

        // --- Needs config ---
        public NeedsConfig Needs;

        // --- Object memory config ---
        public int NpcObjectMemorySlots;       // slot per memoria oggetti interagibili (per NPC)
        public int ObjectMemoryMaxAgeTicks;    // TTL in tick (pulizia)


        // --- Landmark pathfinding (v0.02) ---
        // Day1: solo flag + parametri; la logica viene implementata nei giorni successivi.
        public bool EnableLandmarkSystem;
        public int MaxLandmarksPerNpc;
        public int MaxEdgesPerNpc;
        public int MaxPoiAnchorsPerNpc;
        public int MaxWorldLandmarks;

        // Day3: eviction params (NPC-side landmark memory)
        // Nota: li teniamo qui per evitare che i System leggano direttamente Config/SIM ogni tick.
        // Sono parametri di policy, quindi hanno senso come "global tunables" data-driven.
        public int LandmarkEvictionStaleTicks;
        public int LandmarkEvictionCooldownTicks;

        // --- Inventory / Carry capacity ---
        //
        // NOTA:
        // - "InventoryMaxUnits" è la capienza massima (in unità) dell'inventario di un NPC.
        // - È un parametro di configurazione letto da game_params.json (SimulationParams.inventory.inventory_max_units).
        // - La simulazione deve usare UNA query centrale (World.GetInventoryFreeCapacity)
        //   per evitare logiche divergenti tra comandi/sistemi.
        public int InventoryMaxUnits;

        // Tick corrente (se lo vuoi accessibile anche qui; altrimenti usa TickContext)
        public long CurrentTickIndex;
    }

    public struct GridPosition
    {
        public int X;
        public int Y;

        public GridPosition(int x, int y)
        {
            X = x;
            Y = y;
        }
    }
}

// Classe che contiene i parametri del simulatore letti da game_params.json
public sealed class WorldConfig
{
    public Arcontio.Core.Config.SimulationParams Sim { get; }

    public WorldConfig(Arcontio.Core.Config.SimulationParams sim)
    {
        Sim = sim;
    }
}