using System.Collections.Generic;
using Arcontio.Core.Diagnostics;
using Arcontio.Core.Logging;
using UnityEngine;

namespace Arcontio.Core
{
    /// <summary>
    /// MovementSystem (Day10):
    /// Consuma MoveIntent e prova ad avanzare di 1 cella per tick.
    ///
    /// Baseline volutamente semplice (v0.01):
    /// - distanza Manhattan
    /// - 1 step per tick
    /// - collisione minima: non entra fuori bounds, non entra in celle bloccate da movimento,
    ///   non entra in cella con NPC (1 NPC per cella, standard).
    ///
    /// Questo è sufficiente per:
    /// - muoversi verso cibo/letto
    /// - testare occlusione/LOS e witness dei furti
    ///
    /// In futuro:
    /// - pathfinding
    /// - gestione porte (auto-open durante MoveTo)
    /// - NpcMovedEvent / PerceptionDirty event-driven
    ///
    /// PATCH NOTE (runtime fix):
    /// - Introduciamo "stuck detection" per MoveIntent:
    ///   se il target cell è occupato o il movimento fallisce ripetutamente,
    ///   dopo N tick cancelliamo l'intento (così le Rules possono re-plan).
    /// - Introduciamo anche "target validation" per TargetObjectId:
    ///   se l'oggetto target scompare / viene consumato / si sposta altrove,
    ///   cancelliamo l'intento perché la cella target non è più significativa.
    ///
    /// Motivazione:
    /// - Con lo standard "1 NPC per cella", è frequente che un NPC insegua una cella
    ///   che nel frattempo diventa occupata (es. stock cibo su cui un altro NPC sta mangiando).
    /// - Senza invalidazione, l'NPC rimane piantato con intent attivo verso una cella
    ///   irraggiungibile, anche se esistono target alternativi.
    ///
    /// PATCH 0.02.05.2:
    /// - Regola 1: Direct Path Override.
    ///   Se il target finale è raggiungibile con passaggio diretto cardinale reale,
    ///   l'NPC ignora completamente la macro-route landmark.
    ///
    /// - Regola 2: Goal-Oriented Local Search.
    ///   Se la macro-route non basta, oppure il passo verso il prossimo checkpoint
    ///   si rivela localmente infelice/bloccante, l'NPC prova una ricerca locale
    ///   orientata al target finale.
    ///
    /// Nota importantissima sull'algoritmo usato per la Local Search:
    /// - il documento indicato dall'utente è Jump Point Search (JPS), pensato per griglie
    ///   uniform-cost e per potare grandi porzioni simmetriche dello spazio di ricerca.
    /// - qui adottiamo una variante volutamente limitata e locale, coerente con ARCONTIO:
    ///   una ricerca bounded "JPS-style" su griglia 4-direzionale, con espansione a jump point,
    ///   pruning per linee dritte e forced-neighbour detection per i casi cardinali.
    /// - NON stiamo introducendo un pathfinder globale onnisciente del mondo intero.
    ///   Stiamo introducendo un fallback locale, con budget finito, che serve a simulare
    ///   il comportamento ragionevole di un NPC che gira attorno a un blocco continuando
    ///   a tendere verso il suo obiettivo.
    /// </summary>
    public sealed class MovementSystem : ISystem
    {
        public int Period => 1;

        // IMPORTANTISSIMO (design + debug):
        // Questi valori dovrebbero essere letti da config (game_params.json).
        // Per ora li teniamo qui come baseline sicura per chiudere un bug runtime.
        // Step successivo (5.1/6A) potrà renderli data-driven.
        private const int DefaultIntentStuckTicks = 12;

        // Ogni quanti tick rivalutiamo la validità dell'oggetto target (TargetObjectId).
        // 1 = ogni tick (più robusto, un po' più costoso ma N è piccolo in Day10).
        private const int DefaultTargetValidateEveryTicks = 1;

        // ============================================================
        // LOCAL SEARCH TUNING (v0.02.05.2)
        // ============================================================
        // Budget logico della ricerca locale. Non rappresenta "nodi espansi" puri:
        // è il budget esecutivo che l'NPC può spendere nel continuare ad affidarsi
        // al fallback locale prima di dichiararlo fallito.
        private const int DefaultLocalSearchBudget = 18;

        // Limite di espansioni del planner locale JPS-style.
        // Essendo una ricerca volutamente locale, preferiamo un bound molto chiaro.
        private const int DefaultLocalSearchMaxExpanded = 160;

        // Raggio locale intorno al rettangolo start-goal entro cui siamo autorizzati
        // a cercare. Questo impedisce che il fallback locale si trasformi in un
        // pathfinding globale mascherato.
        private const int DefaultLocalSearchPadding = 8;

        private static readonly Direction4[] AllDirections =
        {
            new Direction4( 1,  0),
            new Direction4(-1,  0),
            new Direction4( 0,  1),
            new Direction4( 0, -1),
        };

        public void Update(World world, Tick tick, MessageBus bus, Telemetry telemetry)
        {
             // Nota: iteriamo su NpcCore.Keys (source of truth degli NPC esistenti)
            foreach (var npcId in world.NpcCore.Keys)
            {
                if (!world.NpcMoveIntents.TryGetValue(npcId, out var intent) || !intent.Active)
                    continue;
                if (!world.GridPos.TryGetValue(npcId, out var pos))
                    continue;

                // Day5: se esiste una macro-route in esecuzione, prima di qualsiasi altra cosa
                // proviamo a far avanzare lo stato rispetto alla cella corrente.
                // Questo gestisce correttamente il caso in cui l'NPC parta gia' sopra lo start landmark
                // oppure entri sul prossimo landmark e debba immediatamente passare allo step successivo.
                world.TryAdvanceMacroRouteExecutionAtCell(npcId, pos.X, pos.Y);

                // PATCH 0.02.05.2:
                // Facciamo avanzare anche l'eventuale stato di local search già attivo.
                // Questo è essenziale perché il planner locale produce un path cella-per-cella:
                // quando l'NPC entra nella prossima cella del path, dobbiamo aggiornare il target immediato.
                world.TryAdvanceGoalLocalSearchAtCell(npcId, pos.X, pos.Y);

                int finalTargetX = intent.TargetX;
                int finalTargetY = intent.TargetY;

                int effectiveTargetX = finalTargetX;
                int effectiveTargetY = finalTargetY;
                bool macroLastMile = false;
                bool usingMacroTarget = false;
                bool usingLocalSearch = false;
                int macroNextNodeId = 0;

                if (world.TryGetMacroExecutionImmediateTarget(npcId, out int macroTargetX, out int macroTargetY, out macroLastMile, out macroNextNodeId))
                {
                    effectiveTargetX = macroTargetX;
                    effectiveTargetY = macroTargetY;
                    usingMacroTarget = true;
                }

                // PATCH NOTE:
                // Validazione "oggetto target" (se presente).
                // Se target sparisce / è vuoto / si sposta, cancelliamo l'intento.
                if (ShouldValidateTargetThisTick(tick))
                {
                    if (!ValidateOrCancelTarget(world, npcId, ref intent))
                    {
                        // intent già cancellato dentro ValidateOrCancelTarget.
                        world.ClearGoalLocalSearchForNpc(npcId);
                        continue;
                    }
                }

                int x = pos.X;
                int y = pos.Y;

                // ============================================================
                // REGOLA 1 - DIRECT PATH OVERRIDE
                // ============================================================
                // Se esiste un passaggio diretto cardinale reale verso il target finale,
                // la verità percettiva locale batte la macro-route landmark.
                //
                // Nota importante:
                // - qui NON stiamo chiedendo "esiste un qualunque path nel mondo?".
                // - stiamo chiedendo qualcosa di molto più stretto e coerente con la regola:
                //   esiste una progressione diretta e monotona (X-then-Y oppure Y-then-X)
                //   senza ostacoli reali?
                //
                // Se la risposta è sì, non ha nessun senso continuare a seguire checkpoint landmark.
                if (HasDirectCardinalPath(world, npcId, x, y, finalTargetX, finalTargetY))
                {
                    effectiveTargetX = finalTargetX;
                    effectiveTargetY = finalTargetY;
                    usingMacroTarget = false;
                    usingLocalSearch = false;
                    world.ClearGoalLocalSearchForNpc(npcId);
                }
                else
                {
                    // ============================================================
                    // REGOLA 2 - GOAL-ORIENTED LOCAL SEARCH
                    // ============================================================
                    // Priorità operativa:
                    // 1) se una local search è già attiva, continuiamo quella;
                    // 2) se non c'è una macro-route utile, proviamo a crearne una locale;
                    // 3) se siamo nell'ultimo tratto della macro-route, proviamo a creare una locale;
                    // 4) altrimenti continuiamo con il target macro corrente.
                    if (world.TryGetGoalLocalSearchImmediateTarget(npcId, out int lsTargetX, out int lsTargetY, out int lsBudget) && lsBudget > 0)
                    {
                        effectiveTargetX = lsTargetX;
                        effectiveTargetY = lsTargetY;
                        usingMacroTarget = false;
                        usingLocalSearch = true;
                    }
                    else if (!usingMacroTarget || macroLastMile)
                    {
                        if (TryStartGoalOrientedLocalSearch(world, npcId, x, y, finalTargetX, finalTargetY, out lsTargetX, out lsTargetY))
                        {
                            effectiveTargetX = lsTargetX;
                            effectiveTargetY = lsTargetY;
                            usingMacroTarget = false;
                            usingLocalSearch = true;
                        }
                    }
                }

                // ============================================================
                // DEBUG MODE TAGGING (v0.02.05.2 follow-up)
                // ============================================================
                // Qui NON stiamo cambiando la logica di movimento.
                // Stiamo solo rendendo esplicito, lato osservabilità, in quale
                // modalità di navigazione si trova l'NPC in questo preciso tick.
                if (usingLocalSearch)
                {
                    world.SetMacroRouteNavigationMode(npcId, "GOAL_ORIENTED_LOCAL_SEARCH", "FollowingActiveGoalLocalSearch");
                }
                else if (!usingMacroTarget)
                {
                    world.SetMacroRouteNavigationMode(npcId, "DIRECT_OVERRIDE", "DirectPathOverride");
                }
                else if (macroLastMile)
                {
                    world.SetMacroRouteNavigationMode(npcId, "LAST_MILE_DIRECT", "MacroRouteLastMile");
                }
                else
                {
                    world.SetMacroRouteNavigationMode(npcId, "LM_PATH", "FollowingLandmarkMacroRoute");
                }

                // ACTION TRACE (debug/overlay): durante un MoveIntent attivo, l'NPC è in azione MoveTo.
                // IMPORTANTISSIMO: non vogliamo resettare StartedTick ogni tick; quindi settiamo solo se serve.
                if (world.TryGetNpcAction(npcId, out var act))
                {
                    if (act.Kind != NpcActionKind.MoveTo || !act.HasTargetCell || act.TargetX != effectiveTargetX || act.TargetY != effectiveTargetY)
                        world.SetNpcAction(npcId, NpcActionState.MoveTo(effectiveTargetX, effectiveTargetY, intent.Reason.ToString()));
                }
                else
                {
                    world.SetNpcAction(npcId, NpcActionState.MoveTo(effectiveTargetX, effectiveTargetY, intent.Reason.ToString()));
                }

                // Se siamo arrivati al target FINALE, disattiviamo.
                // Nota molto importante:
                // - qui NON guardiamo il target immediato della macro/local search.
                // - guardiamo il target finale del MoveIntent, che è la vera semantica del comando.
                if (x == finalTargetX && y == finalTargetY)
                {
                    intent.Active = false;
                    intent.BlockedTicks = 0;
                    world.NpcMoveIntents[npcId] = intent;
                    world.SetNpcIdle(npcId);
                    world.ClearGoalLocalSearchForNpc(npcId);
                    continue;
                }

                // Step greedy: preferisci asse con maggiore distanza.
                int dx = effectiveTargetX - x;
                int dy = effectiveTargetY - y;

                int stepX = 0;
                int stepY = 0;

                if (Mathf.Abs(dx) >= Mathf.Abs(dy))
                    stepX = dx == 0 ? 0 : (dx > 0 ? 1 : -1);
                else
                    stepY = dy == 0 ? 0 : (dy > 0 ? 1 : -1);

                // Se l'asse scelto è 0 (perché dx==0 e Abs(dx)>=Abs(dy)), proviamo l'altro.
                if (stepX == 0 && stepY == 0)
                {
                    // Non dovrebbe succedere perché abbiamo gestito "arrivati" sopra, ma restiamo difensivi.
                    intent.Active = false;
                    intent.BlockedTicks = 0;
                    world.NpcMoveIntents[npcId] = intent;
                    world.SetNpcIdle(npcId);
                    world.ClearGoalLocalSearchForNpc(npcId);
                    continue;
                }

                bool moved = false;
                int movedToX = x;
                int movedToY = y;

                // Tentativo 1: step scelto
                if (TryMoveTo(world, npcId, x + stepX, y + stepY))
                {
                    moved = true;
                    movedToX = x + stepX;
                    movedToY = y + stepY;
                }
                else
                {
                    // Tentativo 2: prova sull'altro asse (fallback minimo)
                    if (stepX != 0)
                    {
                        stepX = 0;
                        stepY = dy == 0 ? 0 : (dy > 0 ? 1 : -1);
                    }
                    else
                    {
                        stepY = 0;
                        stepX = dx == 0 ? 0 : (dx > 0 ? 1 : -1);
                    }

                    // Se anche il fallback non è possibile, restiamo fermi.
                    // Nota: se stepX/stepY sono entrambi 0, TryMoveTo fallirà (bounds) ma preferiamo essere espliciti.
                    if (stepX != 0 || stepY != 0)
                        if (TryMoveTo(world, npcId, x + stepX, y + stepY))
                        {
                            moved = true;
                            movedToX = x + stepX;
                            movedToY = y + stepY;
                        }
                }

                // PATCH 0.02.05.2 - reroute immediato su local search.
                // Se il passo verso il target macro si rivela bloccato localmente,
                // proviamo subito a sostituirlo con un path locale JPS-style verso il target finale.
                //
                // Questo è esattamente il caso "arrivo vicino al landmark giusto ma il passaggio reale
                // non è quello che credevo". È il cuore della nuova regola 2.
                if (!moved && !usingLocalSearch)
                {
                    if (TryStartGoalOrientedLocalSearch(world, npcId, x, y, finalTargetX, finalTargetY, out int lsTargetX, out int lsTargetY))
                    {
                        int lsDx = lsTargetX - x;
                        int lsDy = lsTargetY - y;
                        int lsStepX = 0;
                        int lsStepY = 0;

                        if (Mathf.Abs(lsDx) >= Mathf.Abs(lsDy))
                            lsStepX = lsDx == 0 ? 0 : (lsDx > 0 ? 1 : -1);
                        else
                            lsStepY = lsDy == 0 ? 0 : (lsDy > 0 ? 1 : -1);

                        if (lsStepX != 0 || lsStepY != 0)
                        {
                            if (TryMoveTo(world, npcId, x + lsStepX, y + lsStepY))
                            {
                                moved = true;
                                movedToX = x + lsStepX;
                                movedToY = y + lsStepY;
                                usingLocalSearch = true;
                                usingMacroTarget = false;
                            }
                            else
                            {
                                // Proviamo il fallback sull'altro asse anche per il target locale immediato.
                                if (lsStepX != 0)
                                {
                                    lsStepX = 0;
                                    lsStepY = lsDy == 0 ? 0 : (lsDy > 0 ? 1 : -1);
                                }
                                else
                                {
                                    lsStepY = 0;
                                    lsStepX = lsDx == 0 ? 0 : (lsDx > 0 ? 1 : -1);
                                }

                                if ((lsStepX != 0 || lsStepY != 0) && TryMoveTo(world, npcId, x + lsStepX, y + lsStepY))
                                {
                                    moved = true;
                                    movedToX = x + lsStepX;
                                    movedToY = y + lsStepY;
                                    usingLocalSearch = true;
                                    usingMacroTarget = false;
                                }
                            }
                        }
                    }
                }

                // PATCH NOTE:
                // - Se ci siamo mossi: resettiamo BlockedTicks.
                // - Se NON ci siamo mossi: incrementiamo BlockedTicks.
                //   Dopo DefaultIntentStuckTicks tick di blocco, cancelliamo l'intento.
                if (moved)
                {
                    // ============================================================
                    // Landmark learning hook (v0.02 Day3)
                    // ============================================================
                    //
                    // IMPORTANTISSIMO (ARCONTIO design):
                    // - l'NPC impara landmark/edge SOLO tramite esperienza (movimento).
                    // - questa chiamata aggiorna la memoria soggettiva (NpcLandmarkMemory)
                    //   usando il registry oggettivo (LandmarkRegistry) come fonte di nodi/edge validi.
                    //
                    world.NotifyNpcMovedForLandmarkLearning(npcId, fromX: x, fromY: y, toX: movedToX, toY: movedToY);

                    intent.BlockedTicks = 0;
                    world.NpcMoveIntents[npcId] = intent;

                    if (usingLocalSearch)
                        world.ConsumeGoalLocalSearchBudget(npcId, amount: 1);
                }
                else
                {
                    intent.BlockedTicks++;

                    if (intent.BlockedTicks >= DefaultIntentStuckTicks)
                    {
                        // Cancelliamo l'intento: il target cell è di fatto irraggiungibile (occupata o bloccata).
                        // Questo sblocca la simulazione: al tick successivo le Rules possono fare re-plan
                        // scegliendo un target alternativo (altro cibo in vista/memoria, ecc.).
                        intent.Active = false;
                        intent.BlockedTicks = 0;
                        world.NpcMoveIntents[npcId] = intent;
                        world.SetNpcIdle(npcId);
                        world.MarkMacroRouteExecutionBlocked(npcId, duringLastMile: macroLastMile);
                        world.MarkGoalLocalSearchFailed(npcId, "BlockedDuringLocalSearchOrDirectMove");

                        ArcontioLogger.Trace(
                            new LogContext(tick: (int)TickContext.CurrentTickIndex, channel: "Move", npcId: npcId, cell: (x, y)),
                            new LogBlock(LogLevel.Trace, "log.move.intent_cancelled_stuck")
                                .AddField("targetX", intent.TargetX)
                                .AddField("targetY", intent.TargetY)
                                .AddField("reason", intent.Reason.ToString())
                        );
                    }
                    else
                    {
                        world.NpcMoveIntents[npcId] = intent;
                    }
                }

                // Nota importante (molto verbosa ma utile):
                // In futuro, qui è il punto giusto per:
                // - emettere un "NpcMovedEvent"
                // - settare PerceptionDirty (event-driven perception)
                // Attualmente molti sistemi fanno polling e quindi non è strettamente necessario,
                // ma il documento sight spinge verso trigger dopo movimento/rotazione.
            }
        }

        private static bool ShouldValidateTargetThisTick(Tick tick)
        {
            // Nota: Tick non è necessariamente un int; non conosciamo la tua implementazione.
            // Per evitare dipendenze, usiamo il TickContext globale che già usi per logging.
            // Se DefaultTargetValidateEveryTicks == 1 -> sempre true.
            int t = (int)TickContext.CurrentTickIndex;
            return DefaultTargetValidateEveryTicks <= 1 || (t % DefaultTargetValidateEveryTicks) == 0;
        }

        /// <summary>
        /// Valida TargetObjectId se presente.
        ///
        /// Politica:
        /// - Se TargetObjectId non esiste più -> intent cancellato.
        /// - Se l'oggetto esiste ma è uno stock cibo con Units<=0 -> intent cancellato.
        /// - Se l'oggetto esiste ma si trova in una cella diversa dal TargetX/Y dell'intent -> intent cancellato.
        ///
        /// Perché cancellare quando l'oggetto si sposta?
        /// - In questo baseline non abbiamo "tracking" intelligente della posizione dell'oggetto.
        /// - La cella target diventa una "last known cell"; la scelta più robusta è cancellare e lasciare re-plan.
        /// </summary>
        private static bool ValidateOrCancelTarget(World world, int npcId, ref MoveIntent intent)
        {
            if (intent.TargetObjectId == 0)
                return true;

            // 1) L'oggetto deve esistere in world.Objects.
            if (!world.Objects.TryGetValue(intent.TargetObjectId, out var obj) || obj == null)
            {
                CancelIntent(world, npcId, ref intent, "missing_object");
                return false;
            }

            // 2) Se l'oggetto è uno stock cibo, deve avere unità > 0.
            //    Nota: questo controlla la "presenza significativa" del target (se vuoto non ha senso inseguirlo).
            if (world.FoodStocks.TryGetValue(intent.TargetObjectId, out var stock))
            {
                if (stock.Units <= 0)
                {
                    CancelIntent(world, npcId, ref intent, "foodstock_empty");
                    return false;
                }
            }

            // 3) Se l'oggetto si è spostato, non ha più senso perseguire la vecchia cella target.
            //    Cancelliamo e demandiamo alle Rules la scelta del nuovo target (via memoria/percezione).
            if (obj.CellX != intent.TargetX || obj.CellY != intent.TargetY)
            {
                CancelIntent(world, npcId, ref intent, "target_moved");
                return false;
            }

            return true;
        }

        private static void CancelIntent(World world, int npcId, ref MoveIntent intent, string why)
        {
            intent.Active = false;
            intent.BlockedTicks = 0;
            world.NpcMoveIntents[npcId] = intent;
            world.SetNpcIdle(npcId);
            world.ClearGoalLocalSearchForNpc(npcId);

            ArcontioLogger.Trace(
                new LogContext(tick: (int)TickContext.CurrentTickIndex, channel: "Move", npcId: npcId, cell: default),
                new LogBlock(LogLevel.Trace, "log.move.intent_cancelled_target_invalid")
                    .AddField("why", why)
                    .AddField("targetX", intent.TargetX)
                    .AddField("targetY", intent.TargetY)
                    .AddField("targetObjectId", intent.TargetObjectId)
                    .AddField("reason", intent.Reason.ToString())
            );
        }

        private static bool TryMoveTo(World world, int npcId, int tx, int ty)
        {
            // Bounds
            if (!world.InBounds(tx, ty))
                return false;

            // Blocco movimento
            if (world.IsMovementBlocked(tx, ty))
                return false;

            // 1 NPC per cell: se c'è già qualcuno non entriamo.
            if (world.TryGetNpcAt(tx, ty, out int otherNpcId) && otherNpcId != npcId)
                return false;

            // Muovi
            world.GridPos[npcId] = new GridPosition(tx, ty);

            ArcontioLogger.Trace(
                new LogContext(tick: (int)TickContext.CurrentTickIndex, channel: "Move", npcId: npcId, cell: (tx, ty)),
                new LogBlock(LogLevel.Trace, "log.move.step")
                    .AddField("x", tx)
                    .AddField("y", ty)
            );

            return true;
        }

        // ============================================================
        // DIRECT PATH HELPERS
        // ============================================================
        private static bool HasDirectCardinalPath(World world, int npcId, int sx, int sy, int tx, int ty)
        {
            return CanTraverseMonotone(world, npcId, sx, sy, tx, ty, xFirst: true)
                || CanTraverseMonotone(world, npcId, sx, sy, tx, ty, xFirst: false);
        }

        private static bool CanTraverseMonotone(World world, int npcId, int sx, int sy, int tx, int ty, bool xFirst)
        {
            int x = sx;
            int y = sy;

            if (xFirst)
            {
                while (x != tx)
                {
                    x += tx > x ? 1 : -1;
                    if (!IsPassableForSearch(world, npcId, x, y, tx, ty))
                        return false;
                }

                while (y != ty)
                {
                    y += ty > y ? 1 : -1;
                    if (!IsPassableForSearch(world, npcId, x, y, tx, ty))
                        return false;
                }
            }
            else
            {
                while (y != ty)
                {
                    y += ty > y ? 1 : -1;
                    if (!IsPassableForSearch(world, npcId, x, y, tx, ty))
                        return false;
                }

                while (x != tx)
                {
                    x += tx > x ? 1 : -1;
                    if (!IsPassableForSearch(world, npcId, x, y, tx, ty))
                        return false;
                }
            }

            return true;
        }

        // ============================================================
        // GOAL-ORIENTED LOCAL SEARCH (JPS-style bounded)
        // ============================================================
        private static bool TryStartGoalOrientedLocalSearch(World world, int npcId, int startX, int startY, int goalX, int goalY, out int immediateTargetX, out int immediateTargetY)
        {
            immediateTargetX = 0;
            immediateTargetY = 0;

            if (startX == goalX && startY == goalY)
                return false;

            if (TryBuildBoundedJumpPointPath(world, npcId, startX, startY, goalX, goalY, DefaultLocalSearchMaxExpanded, DefaultLocalSearchPadding, out var expandedPath))
            {
                world.BeginOrReplaceGoalLocalSearchForNpc(npcId, goalX, goalY, expandedPath, DefaultLocalSearchBudget, failureReason: string.Empty);
                if (world.TryGetGoalLocalSearchImmediateTarget(npcId, out immediateTargetX, out immediateTargetY, out _))
                    return true;
            }

            return false;
        }

        private static bool TryBuildBoundedJumpPointPath(
            World world,
            int npcId,
            int startX,
            int startY,
            int goalX,
            int goalY,
            int maxExpanded,
            int padding,
            out List<GridPosition> expandedPath)
        {
            expandedPath = null;

            if (!world.InBounds(startX, startY) || !world.InBounds(goalX, goalY))
                return false;

            if (!IsPassableForSearch(world, npcId, goalX, goalY, goalX, goalY))
                return false;

            int minX = Mathf.Max(0, Mathf.Min(startX, goalX) - padding);
            int maxX = Mathf.Min(world.MapWidth - 1, Mathf.Max(startX, goalX) + padding);
            int minY = Mathf.Max(0, Mathf.Min(startY, goalY) - padding);
            int maxY = Mathf.Min(world.MapHeight - 1, Mathf.Max(startY, goalY) + padding);

            int startKey = Pack(startX, startY);
            int goalKey = Pack(goalX, goalY);

            var open = new List<SearchNode>(64);
            var gScore = new Dictionary<int, int>(128);
            var cameFrom = new Dictionary<int, int>(128);
            var closed = new HashSet<int>();

            open.Add(new SearchNode(startX, startY, g: 0, f: Heuristic(startX, startY, goalX, goalY)));
            gScore[startKey] = 0;

            int expanded = 0;

            while (open.Count > 0 && expanded < maxExpanded)
            {
                int bestIndex = 0;
                for (int i = 1; i < open.Count; i++)
                {
                    if (open[i].F < open[bestIndex].F || (open[i].F == open[bestIndex].F && open[i].G > open[bestIndex].G))
                        bestIndex = i;
                }

                var current = open[bestIndex];
                open.RemoveAt(bestIndex);

                int currentKey = Pack(current.X, current.Y);
                if (closed.Contains(currentKey))
                    continue;

                closed.Add(currentKey);
                expanded++;

                if (currentKey == goalKey)
                {
                    expandedPath = ReconstructExpandedCellPath(cameFrom, currentKey, startKey);
                    return expandedPath != null && expandedPath.Count > 0;
                }

                for (int d = 0; d < AllDirections.Length; d++)
                {
                    var dir = AllDirections[d];
                    if (!TryJump(world, npcId, current.X, current.Y, dir.Dx, dir.Dy, goalX, goalY, minX, maxX, minY, maxY, out int jumpX, out int jumpY))
                        continue;

                    int jumpKey = Pack(jumpX, jumpY);
                    if (closed.Contains(jumpKey))
                        continue;

                    int tentativeG = current.G + Mathf.Abs(jumpX - current.X) + Mathf.Abs(jumpY - current.Y);
                    if (gScore.TryGetValue(jumpKey, out int knownG) && tentativeG >= knownG)
                        continue;

                    gScore[jumpKey] = tentativeG;
                    cameFrom[jumpKey] = currentKey;
                    open.Add(new SearchNode(jumpX, jumpY, tentativeG, tentativeG + Heuristic(jumpX, jumpY, goalX, goalY)));
                }
            }

            return false;
        }

        private static bool TryJump(
            World world,
            int npcId,
            int startX,
            int startY,
            int dx,
            int dy,
            int goalX,
            int goalY,
            int minX,
            int maxX,
            int minY,
            int maxY,
            out int jumpX,
            out int jumpY)
        {
            jumpX = startX;
            jumpY = startY;

            int x = startX;
            int y = startY;

            while (true)
            {
                x += dx;
                y += dy;

                if (x < minX || x > maxX || y < minY || y > maxY)
                    return false;

                if (!IsPassableForSearch(world, npcId, x, y, goalX, goalY))
                    return false;

                if (x == goalX && y == goalY)
                {
                    jumpX = x;
                    jumpY = y;
                    return true;
                }

                if (HasForcedNeighbour(world, npcId, x, y, dx, dy, goalX, goalY))
                {
                    jumpX = x;
                    jumpY = y;
                    return true;
                }
            }
        }

        private static bool HasForcedNeighbour(World world, int npcId, int x, int y, int dx, int dy, int goalX, int goalY)
        {
            // Variante 4-dir cardinale.
            // L'idea resta fedele al principio del JPS descritto da Harabor:
            // fermarsi quando, a causa di un ostacolo adiacente, una prosecuzione rettilinea
            // genera vicini che non possono essere potati come meri casi simmetrici.
            if (dx != 0)
            {
                // Movimento orizzontale.
                if (IsBlockedForSearch(world, npcId, x, y + 1, goalX, goalY) && IsPassableForSearch(world, npcId, x + dx, y + 1, goalX, goalY))
                    return true;
                if (IsBlockedForSearch(world, npcId, x, y - 1, goalX, goalY) && IsPassableForSearch(world, npcId, x + dx, y - 1, goalX, goalY))
                    return true;
            }
            else if (dy != 0)
            {
                // Movimento verticale.
                if (IsBlockedForSearch(world, npcId, x + 1, y, goalX, goalY) && IsPassableForSearch(world, npcId, x + 1, y + dy, goalX, goalY))
                    return true;
                if (IsBlockedForSearch(world, npcId, x - 1, y, goalX, goalY) && IsPassableForSearch(world, npcId, x - 1, y + dy, goalX, goalY))
                    return true;
            }

            return false;
        }

        private static List<GridPosition> ReconstructExpandedCellPath(Dictionary<int, int> cameFrom, int currentKey, int startKey)
        {
            var jumpKeys = new List<int>(32) { currentKey };
            int walk = currentKey;

            while (cameFrom.TryGetValue(walk, out int prev))
            {
                jumpKeys.Add(prev);
                walk = prev;
            }

            jumpKeys.Reverse();
            if (jumpKeys.Count == 0 || jumpKeys[0] != startKey)
                return null;

            var result = new List<GridPosition>(64);
            int prevX = UnpackX(jumpKeys[0]);
            int prevY = UnpackY(jumpKeys[0]);

            for (int i = 1; i < jumpKeys.Count; i++)
            {
                int nextX = UnpackX(jumpKeys[i]);
                int nextY = UnpackY(jumpKeys[i]);

                int stepX = nextX == prevX ? 0 : (nextX > prevX ? 1 : -1);
                int stepY = nextY == prevY ? 0 : (nextY > prevY ? 1 : -1);

                int x = prevX;
                int y = prevY;
                while (x != nextX || y != nextY)
                {
                    x += stepX;
                    y += stepY;
                    result.Add(new GridPosition(x, y));
                }

                prevX = nextX;
                prevY = nextY;
            }

            return result;
        }

        private static bool IsPassableForSearch(World world, int npcId, int x, int y, int goalX, int goalY)
        {
            if (!world.InBounds(x, y))
                return false;
            if (world.IsMovementBlocked(x, y))
                return false;

            if (world.TryGetNpcAt(x, y, out int otherNpcId) && otherNpcId != npcId)
            {
                // Sul goal finale manteniamo la stessa regola fisica del movimento:
                // se la cella è occupata da un altro NPC, non è passabile.
                return false;
            }

            return true;
        }

        private static bool IsBlockedForSearch(World world, int npcId, int x, int y, int goalX, int goalY)
        {
            return !IsPassableForSearch(world, npcId, x, y, goalX, goalY);
        }

        private static int Heuristic(int x, int y, int goalX, int goalY)
        {
            return Mathf.Abs(goalX - x) + Mathf.Abs(goalY - y);
        }

        private static int Pack(int x, int y) => (y << 16) ^ (x & 0xFFFF);
        private static int UnpackX(int packed) => (short)(packed & 0xFFFF);
        private static int UnpackY(int packed) => packed >> 16;

        private readonly struct SearchNode
        {
            public readonly int X;
            public readonly int Y;
            public readonly int G;
            public readonly int F;

            public SearchNode(int x, int y, int g, int f)
            {
                X = x;
                Y = y;
                G = g;
                F = f;
            }
        }

        private readonly struct Direction4
        {
            public readonly int Dx;
            public readonly int Dy;

            public Direction4(int dx, int dy)
            {
                Dx = dx;
                Dy = dy;
            }
        }
    }
}
