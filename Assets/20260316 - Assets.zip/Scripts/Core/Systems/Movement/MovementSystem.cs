using Arcontio.Core.Diagnostics;
using Arcontio.Core.Logging;
using UnityEngine;

namespace Arcontio.Core
{
    /// <summary>
    /// MovementSystem (Day10):
    /// Consuma MoveIntent e prova ad avanzare di 1 cella per tick.
    ///
    /// Baseline volutamente semplice (v0.01):
    /// - distanza Manhattan
    /// - 1 step per tick
    /// - collisione minima: non entra fuori bounds, non entra in celle bloccate da movimento,
    ///   non entra in cella con NPC (1 NPC per cella, standard).
    ///
    /// Questo è sufficiente per:
    /// - muoversi verso cibo/letto
    /// - testare occlusione/LOS e witness dei furti
    ///
    /// In futuro:
    /// - pathfinding
    /// - gestione porte (auto-open durante MoveTo)
    /// - NpcMovedEvent / PerceptionDirty event-driven
    ///
    /// PATCH NOTE (runtime fix):
    /// - Introduciamo "stuck detection" per MoveIntent:
    ///   se il target cell è occupato o il movimento fallisce ripetutamente,
    ///   dopo N tick cancelliamo l'intento (così le Rules possono re-plan).
    /// - Introduciamo anche "target validation" per TargetObjectId:
    ///   se l'oggetto target scompare / viene consumato / si sposta altrove,
    ///   cancelliamo l'intento perché la cella target non è più significativa.
    ///
    /// Motivazione:
    /// - Con lo standard "1 NPC per cella", è frequente che un NPC insegua una cella
    ///   che nel frattempo diventa occupata (es. stock cibo su cui un altro NPC sta mangiando).
    /// - Senza invalidazione, l'NPC rimane piantato con intent attivo verso una cella
    ///   irraggiungibile, anche se esistono target alternativi.
    /// </summary>
    public sealed class MovementSystem : ISystem
    {
        public int Period => 1;

        // IMPORTANTISSIMO (design + debug):
        // Questi valori dovrebbero essere letti da config (game_params.json).
        // Per ora li teniamo qui come baseline sicura per chiudere un bug runtime.
        // Step successivo (5.1/6A) potrà renderli data-driven.
        private const int DefaultIntentStuckTicks = 12;

        // Ogni quanti tick rivalutiamo la validità dell'oggetto target (TargetObjectId).
        // 1 = ogni tick (più robusto, un po' più costoso ma N è piccolo in Day10).
        private const int DefaultTargetValidateEveryTicks = 1;

        public void Update(World world, Tick tick, MessageBus bus, Telemetry telemetry)
        {
             // Nota: iteriamo su NpcCore.Keys (source of truth degli NPC esistenti)
            foreach (var npcId in world.NpcCore.Keys)
            {
                if (!world.NpcMoveIntents.TryGetValue(npcId, out var intent) || !intent.Active)
                    continue;
                if (!world.GridPos.TryGetValue(npcId, out var pos))
                    continue;

                // PATCH NOTE:
                // Validazione "oggetto target" (se presente).
                // Se target sparisce / è vuoto / si sposta, cancelliamo l'intento.
                if (ShouldValidateTargetThisTick(tick))
                {
                    if (!ValidateOrCancelTarget(world, npcId, ref intent))
                    {
                        // intent già cancellato dentro ValidateOrCancelTarget.
                        continue;
                    }
                }

                // ACTION TRACE (debug/overlay): durante un MoveIntent attivo, l'NPC è in azione MoveTo.
                // IMPORTANTISSIMO: non vogliamo resettare StartedTick ogni tick; quindi settiamo solo se serve.
                if (world.TryGetNpcAction(npcId, out var act))
                {
                    if (act.Kind != NpcActionKind.MoveTo || !act.HasTargetCell || act.TargetX != intent.TargetX || act.TargetY != intent.TargetY)
                        world.SetNpcAction(npcId, NpcActionState.MoveTo(intent.TargetX, intent.TargetY, intent.Reason.ToString()));
                }
                else
                {
                    world.SetNpcAction(npcId, NpcActionState.MoveTo(intent.TargetX, intent.TargetY, intent.Reason.ToString()));
                }

                int x = pos.X;
                int y = pos.Y;

                // Se siamo arrivati, disattiviamo.
                if (x == intent.TargetX && y == intent.TargetY)
                {
                    intent.Active = false;
                    intent.BlockedTicks = 0;
                    world.NpcMoveIntents[npcId] = intent;
                    world.SetNpcIdle(npcId);
                    continue;
                }

                // Step greedy: preferisci asse con maggiore distanza.
                int dx = intent.TargetX - x;
                int dy = intent.TargetY - y;

                int stepX = 0;
                int stepY = 0;

                if (Mathf.Abs(dx) >= Mathf.Abs(dy))
                    stepX = dx == 0 ? 0 : (dx > 0 ? 1 : -1);
                else
                    stepY = dy == 0 ? 0 : (dy > 0 ? 1 : -1);

                // Se l'asse scelto è 0 (perché dx==0 e Abs(dx)>=Abs(dy)), proviamo l'altro.
                if (stepX == 0 && stepY == 0)
                {
                    // Non dovrebbe succedere perché abbiamo gestito "arrivati" sopra, ma restiamo difensivi.
                    intent.Active = false;
                    intent.BlockedTicks = 0;
                    world.NpcMoveIntents[npcId] = intent;
                    world.SetNpcIdle(npcId);
                    continue;
                }

                bool moved = false;
                int movedToX = x;
                int movedToY = y;

                // Tentativo 1: step scelto
                if (TryMoveTo(world, npcId, x + stepX, y + stepY))
                {
                    moved = true;
                    movedToX = x + stepX;
                    movedToY = y + stepY;
                }
                else
                {
                    // Tentativo 2: prova sull'altro asse (fallback minimo)
                    if (stepX != 0)
                    {
                        stepX = 0;
                        stepY = dy == 0 ? 0 : (dy > 0 ? 1 : -1);
                    }
                    else
                    {
                        stepY = 0;
                        stepX = dx == 0 ? 0 : (dx > 0 ? 1 : -1);
                    }

                    // Se anche il fallback non è possibile, restiamo fermi.
                    // Nota: se stepX/stepY sono entrambi 0, TryMoveTo fallirà (bounds) ma preferiamo essere espliciti.
                    if (stepX != 0 || stepY != 0)
                        if (TryMoveTo(world, npcId, x + stepX, y + stepY))
                        {
                            moved = true;
                            movedToX = x + stepX;
                            movedToY = y + stepY;
                        }
                }

                // PATCH NOTE:
                // - Se ci siamo mossi: resettiamo BlockedTicks.
                // - Se NON ci siamo mossi: incrementiamo BlockedTicks.
                //   Dopo DefaultIntentStuckTicks tick di blocco, cancelliamo l'intento.
                if (moved)
                {
                    // ============================================================
                    // Landmark learning hook (v0.02 Day3)
                    // ============================================================
                    //
                    // IMPORTANTISSIMO (ARCONTIO design):
                    // - l'NPC impara landmark/edge SOLO tramite esperienza (movimento).
                    // - questa chiamata aggiorna la memoria soggettiva (NpcLandmarkMemory)
                    //   usando il registry oggettivo (LandmarkRegistry) come fonte di nodi/edge validi.
                    //
                    world.NotifyNpcMovedForLandmarkLearning(npcId, fromX: x, fromY: y, toX: movedToX, toY: movedToY);

                    intent.BlockedTicks = 0;
                    world.NpcMoveIntents[npcId] = intent;
                }
                else
                {
                    intent.BlockedTicks++;

                    if (intent.BlockedTicks >= DefaultIntentStuckTicks)
                    {
                        // Cancelliamo l'intento: il target cell è di fatto irraggiungibile (occupata o bloccata).
                        // Questo sblocca la simulazione: al tick successivo le Rules possono fare re-plan
                        // scegliendo un target alternativo (altro cibo in vista/memoria, ecc.).
                        intent.Active = false;
                        intent.BlockedTicks = 0;
                        world.NpcMoveIntents[npcId] = intent;
                        world.SetNpcIdle(npcId);

                        ArcontioLogger.Trace(
                            new LogContext(tick: (int)TickContext.CurrentTickIndex, channel: "Move", npcId: npcId, cell: (x, y)),
                            new LogBlock(LogLevel.Trace, "log.move.intent_cancelled_stuck")
                                .AddField("targetX", intent.TargetX)
                                .AddField("targetY", intent.TargetY)
                                .AddField("reason", intent.Reason.ToString())
                        );
                    }
                    else
                    {
                        world.NpcMoveIntents[npcId] = intent;
                    }
                }

                // Nota importante (molto verbosa ma utile):
                // In futuro, qui è il punto giusto per:
                // - emettere un "NpcMovedEvent"
                // - settare PerceptionDirty (event-driven perception)
                // Attualmente molti sistemi fanno polling e quindi non è strettamente necessario,
                // ma il documento sight spinge verso trigger dopo movimento/rotazione.
            }
        }

        private static bool ShouldValidateTargetThisTick(Tick tick)
        {
            // Nota: Tick non è necessariamente un int; non conosciamo la tua implementazione.
            // Per evitare dipendenze, usiamo il TickContext globale che già usi per logging.
            // Se DefaultTargetValidateEveryTicks == 1 -> sempre true.
            int t = (int)TickContext.CurrentTickIndex;
            return DefaultTargetValidateEveryTicks <= 1 || (t % DefaultTargetValidateEveryTicks) == 0;
        }

        /// <summary>
        /// Valida TargetObjectId se presente.
        ///
        /// Politica:
        /// - Se TargetObjectId non esiste più -> intent cancellato.
        /// - Se l'oggetto esiste ma è uno stock cibo con Units<=0 -> intent cancellato.
        /// - Se l'oggetto esiste ma si trova in una cella diversa dal TargetX/Y dell'intent -> intent cancellato.
        ///
        /// Perché cancellare quando l'oggetto si sposta?
        /// - In questo baseline non abbiamo "tracking" intelligente della posizione dell'oggetto.
        /// - La cella target diventa una "last known cell"; la scelta più robusta è cancellare e lasciare re-plan.
        /// </summary>
        private static bool ValidateOrCancelTarget(World world, int npcId, ref MoveIntent intent)
        {
            if (intent.TargetObjectId == 0)
                return true;

            // 1) L'oggetto deve esistere in world.Objects.
            if (!world.Objects.TryGetValue(intent.TargetObjectId, out var obj) || obj == null)
            {
                CancelIntent(world, npcId, ref intent, "missing_object");
                return false;
            }

            // 2) Se l'oggetto è uno stock cibo, deve avere unità > 0.
            //    Nota: questo controlla la "presenza significativa" del target (se vuoto non ha senso inseguirlo).
            if (world.FoodStocks.TryGetValue(intent.TargetObjectId, out var stock))
            {
                if (stock.Units <= 0)
                {
                    CancelIntent(world, npcId, ref intent, "foodstock_empty");
                    return false;
                }
            }

            // 3) Se l'oggetto si è spostato, non ha più senso perseguire la vecchia cella target.
            //    Cancelliamo e demandiamo alle Rules la scelta del nuovo target (via memoria/percezione).
            if (obj.CellX != intent.TargetX || obj.CellY != intent.TargetY)
            {
                CancelIntent(world, npcId, ref intent, "target_moved");
                return false;
            }

            return true;
        }

        private static void CancelIntent(World world, int npcId, ref MoveIntent intent, string why)
        {
            intent.Active = false;
            intent.BlockedTicks = 0;
            world.NpcMoveIntents[npcId] = intent;
            world.SetNpcIdle(npcId);

            ArcontioLogger.Trace(
                new LogContext(tick: (int)TickContext.CurrentTickIndex, channel: "Move", npcId: npcId, cell: default),
                new LogBlock(LogLevel.Trace, "log.move.intent_cancelled_target_invalid")
                    .AddField("why", why)
                    .AddField("targetX", intent.TargetX)
                    .AddField("targetY", intent.TargetY)
                    .AddField("targetObjectId", intent.TargetObjectId)
                    .AddField("reason", intent.Reason.ToString())
            );
        }

        private static bool TryMoveTo(World world, int npcId, int tx, int ty)
        {
            // Bounds
            if (!world.InBounds(tx, ty))
                return false;

            // Blocco movimento
            if (world.IsMovementBlocked(tx, ty))
                return false;

            // 1 NPC per cell: se c'è già qualcuno non entriamo.
            if (world.TryGetNpcAt(tx, ty, out _))
                return false;

            // Muovi
            world.GridPos[npcId] = new GridPosition(tx, ty);

            ArcontioLogger.Trace(
                new LogContext(tick: (int)TickContext.CurrentTickIndex, channel: "Move", npcId: npcId, cell: (tx, ty)),
                new LogBlock(LogLevel.Trace, "log.move.step")
                    .AddField("x", tx)
                    .AddField("y", ty)
            );

            return true;
        }
    }
}
