using System;

namespace Arcontio.Core
{
    /// <summary>
    /// (v0.02 Day1) Tipi di supporto per osservabilità del sistema Landmark.
    ///
    /// Importante:
    /// - In Day1 NON esiste ancora il LandmarkRegistry né la memoria soggettiva di landmark/edges.
    /// - Questi tipi sono "contratti" view/core per:
    ///   1) Debug report stampabile / visualizzabile nella SummaryOverlay.
    ///   2) Debug overlay (nodi + linee) nella MapGrid view.
    ///
    /// Quando implementeremo i giorni successivi, questi stessi contratti verranno popolati
    /// con dati reali (e non con zeri / liste vuote).
    /// </summary>
    [Serializable]
    public readonly struct NpcLandmarkDebugReport
    {
        public readonly int KnownLandmarksCount;
        public readonly int KnownEdgesCount;
        public readonly int PoiAnchorCount;

        public readonly float ReplansPerMin;
        public readonly float FailuresPerMin;

        public readonly int BlacklistSize;

        public NpcLandmarkDebugReport(
            int knownLandmarksCount,
            int knownEdgesCount,
            int poiAnchorCount,
            float replansPerMin,
            float failuresPerMin,
            int blacklistSize)
        {
            KnownLandmarksCount = knownLandmarksCount;
            KnownEdgesCount = knownEdgesCount;
            PoiAnchorCount = poiAnchorCount;
            ReplansPerMin = replansPerMin;
            FailuresPerMin = failuresPerMin;
            BlacklistSize = blacklistSize;
        }
    }

    /// <summary>
    /// Nodo landmark per overlay view-only.
    /// - cellX/cellY: coordinate su griglia.
    /// - kind: enumerazione leggera (0=generic) così la view può differenziare marker in futuro.
    /// </summary>
    [Serializable]
    public readonly struct LandmarkOverlayNode
    {
        public readonly int CellX;
        public readonly int CellY;
        public readonly int Kind;

        public LandmarkOverlayNode(int cellX, int cellY, int kind = 0)
        {
            CellX = cellX;
            CellY = cellY;
            Kind = kind;
        }
    }

    /// <summary>
    /// Edge landmark per overlay view-only.
    /// - A=(ax,ay), B=(bx,by) in coordinate cella.
    /// - reliability01: 0..1 (quando avremo decay/learning).
    /// </summary>
    [Serializable]
    public readonly struct LandmarkOverlayEdge
    {
        public readonly int Ax;
        public readonly int Ay;
        public readonly int Bx;
        public readonly int By;
        public readonly float Reliability01;

        public LandmarkOverlayEdge(int ax, int ay, int bx, int by, float reliability01 = 1f)
        {
            Ax = ax;
            Ay = ay;
            Bx = bx;
            By = by;
            Reliability01 = reliability01;
        }
    }
}
