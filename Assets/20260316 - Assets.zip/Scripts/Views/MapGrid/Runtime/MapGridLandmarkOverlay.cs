using System.Collections.Generic;
using UnityEngine;
using Arcontio.Core;

namespace Arcontio.View.MapGrid
{
    /// <summary>
    /// Debug overlay per il sistema Landmark.
    ///
    /// Patch hotfix:
    /// - disegna SEMPRE il grafo WORLD nel colore "storico" dell'overlay;
    /// - disegna SOPRA, in un colore diverso, il subset KNOWN dell'NPC attivo.
    ///
    /// In questo modo lo sviluppatore vede contemporaneamente:
    /// 1) la struttura oggettiva della mappa;
    /// 2) cosa l'NPC ha effettivamente imparato.
    /// </summary>
    public sealed class MapGridLandmarkOverlay
    {
        private Transform _root;
        private float _tileSizeWorld;
        private int _sortingOrder;

        private Sprite _nodeSprite;
        private Material _lineMaterial;

        // Layer WORLD (grafo oggettivo)
        private readonly List<SpriteRenderer> _worldNodePool = new();
        private readonly List<LineRenderer> _worldEdgePool = new();
        private readonly List<LandmarkOverlayNode> _worldNodes = new();
        private readonly List<LandmarkOverlayEdge> _worldEdges = new();

        // Layer KNOWN (grafo soggettivo dell'NPC)
        private readonly List<SpriteRenderer> _knownNodePool = new();
        private readonly List<LineRenderer> _knownEdgePool = new();
        private readonly List<LandmarkOverlayNode> _knownNodes = new();
        private readonly List<LandmarkOverlayEdge> _knownEdges = new();

        private bool _enabled;

        // Colori hardcoded di debug: nessun nuovo parametro JSON.
        private static readonly Color WorldColor = new Color(1f, 1f, 1f, 0.85f);
        private static readonly Color KnownColor = new Color(0.20f, 1.00f, 0.55f, 1f);

        public void Init(Transform parent, float tileSizeWorld, string nodeSpriteResourcesPath, int sortingOrder)
        {
            _tileSizeWorld = tileSizeWorld;
            _sortingOrder = sortingOrder;

            var go = new GameObject("LandmarkOverlay");
            _root = go.transform;
            _root.SetParent(parent, false);

            _nodeSprite = Resources.Load<Sprite>(nodeSpriteResourcesPath);
            if (_nodeSprite == null)
                Debug.LogWarning($"[MapGrid] Landmark overlay sprite not found at Resources/{nodeSpriteResourcesPath}.png");

            var shader = Shader.Find("Sprites/Default");
            if (shader != null)
                _lineMaterial = new Material(shader);

            SetEnabled(false);
        }

        public void SetEnabled(bool enabled)
        {
            _enabled = enabled;

            if (_root != null)
                _root.gameObject.SetActive(enabled);

            if (!enabled)
                Clear();
        }

        public bool IsEnabled => _enabled;

        public void Clear()
        {
            DisableAll(_worldNodePool);
            DisableAll(_worldEdgePool);
            DisableAll(_knownNodePool);
            DisableAll(_knownEdgePool);
        }

        public void Render(World world, int npcId)
        {
            if (!_enabled || world == null || _root == null)
                return;

            world.GetNpcLandmarkOverlayData(npcId, _worldNodes, _worldEdges, _knownNodes, _knownEdges);

            RenderNodes(_worldNodes, _worldNodePool, WorldColor, nodeScale: 0.35f);
            RenderEdges(_worldEdges, _worldEdgePool, WorldColor, width: 0.03f);

            // Il layer known deve essere leggibile sopra al world: lo facciamo leggermente piu' grande/spesso.
            RenderNodes(_knownNodes, _knownNodePool, KnownColor, nodeScale: 0.48f);
            RenderEdges(_knownEdges, _knownEdgePool, KnownColor, width: 0.055f);
        }

        private void RenderNodes(List<LandmarkOverlayNode> nodes, List<SpriteRenderer> pool, Color color, float nodeScale)
        {
            EnsureNodePool(pool, nodes.Count, color, nodeScale);

            for (int i = 0; i < nodes.Count; i++)
            {
                var n = nodes[i];
                var sr = pool[i];
                sr.gameObject.SetActive(true);
                sr.transform.localPosition = new Vector3((n.CellX + 0.5f) * _tileSizeWorld, (n.CellY + 0.5f) * _tileSizeWorld, 0f);
                sr.sprite = _nodeSprite;
            }

            for (int i = nodes.Count; i < pool.Count; i++)
                pool[i].gameObject.SetActive(false);
        }

        private void RenderEdges(List<LandmarkOverlayEdge> edges, List<LineRenderer> pool, Color color, float width)
        {
            EnsureEdgePool(pool, edges.Count, color, width);

            for (int i = 0; i < edges.Count; i++)
            {
                var e = edges[i];
                var lr = pool[i];
                lr.gameObject.SetActive(true);

                Vector3 a = new Vector3((e.Ax + 0.5f) * _tileSizeWorld, (e.Ay + 0.5f) * _tileSizeWorld, 0f);
                Vector3 b = new Vector3((e.Bx + 0.5f) * _tileSizeWorld, (e.By + 0.5f) * _tileSizeWorld, 0f);

                lr.positionCount = 2;
                lr.startWidth = width;
                lr.endWidth = width;
                lr.startColor = color;
                lr.endColor = color;
                lr.SetPosition(0, a);
                lr.SetPosition(1, b);
            }

            for (int i = edges.Count; i < pool.Count; i++)
                pool[i].gameObject.SetActive(false);
        }

        private void EnsureNodePool(List<SpriteRenderer> pool, int needed, Color color, float nodeScale)
        {
            while (pool.Count < needed)
            {
                var go = new GameObject($"LM_Node_{pool.Count}");
                go.transform.SetParent(_root, false);

                var sr = go.AddComponent<SpriteRenderer>();
                sr.sortingOrder = _sortingOrder;
                sr.sprite = _nodeSprite;
                sr.color = color;
                go.transform.localScale = Vector3.one * nodeScale;

                pool.Add(sr);
            }

            for (int i = 0; i < pool.Count; i++)
            {
                if (pool[i] == null) continue;
                pool[i].color = color;
                pool[i].transform.localScale = Vector3.one * nodeScale;
                pool[i].sortingOrder = _sortingOrder;
            }
        }

        private void EnsureEdgePool(List<LineRenderer> pool, int needed, Color color, float width)
        {
            while (pool.Count < needed)
            {
                var go = new GameObject($"LM_Edge_{pool.Count}");
                go.transform.SetParent(_root, false);

                var lr = go.AddComponent<LineRenderer>();
                lr.useWorldSpace = false;
                lr.loop = false;
                lr.widthMultiplier = 1f;
                lr.sortingOrder = _sortingOrder;
                if (_lineMaterial != null)
                    lr.material = _lineMaterial;

                pool.Add(lr);
            }

            for (int i = 0; i < pool.Count; i++)
            {
                var lr = pool[i];
                if (lr == null) continue;
                lr.sortingOrder = _sortingOrder;
                if (_lineMaterial != null)
                    lr.material = _lineMaterial;
                lr.startColor = color;
                lr.endColor = color;
                lr.startWidth = width;
                lr.endWidth = width;
            }
        }

        private static void DisableAll(List<SpriteRenderer> pool)
        {
            for (int i = 0; i < pool.Count; i++)
            {
                if (pool[i] != null) pool[i].gameObject.SetActive(false);
            }
        }

        private static void DisableAll(List<LineRenderer> pool)
        {
            for (int i = 0; i < pool.Count; i++)
            {
                if (pool[i] != null) pool[i].gameObject.SetActive(false);
            }
        }
    }
}
