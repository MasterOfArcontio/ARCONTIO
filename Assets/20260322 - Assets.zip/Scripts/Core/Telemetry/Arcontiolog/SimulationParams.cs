using System;
using UnityEngine;

namespace Arcontio.Core.Config
{
    /// <summary>
    /// SimulationParams:
    /// contenitore dei parametri di simulazione letti da Resources/Arcontio/Config/game_params.json.
    ///
    /// NOTE IMPORTANTI (storico patch):
    /// - Questo file viene deserializzato tramite JsonUtility.
    /// - JsonUtility ignora i campi sconosciuti: è lecito avere nel JSON sezioni consumate
    ///   da altri sistemi (es: Logging per il logger) senza duplicarle qui.
    /// - Qui mettiamo SOLO parametri che influenzano la simulazione o debug tooling
    ///   strettamente legato alla simulazione (overlay/read-only).
    ///
    /// Patch 0.02D2_1 (questo file):
    /// - Migrazione configurazione debug landmarks:
    ///   PRIMA: root "debug_landmarks".
    ///   ORA:   "landmarks.debug".
    ///
    /// Motivazione:
    /// - un solo source of truth: il debug è una proprietà del sistema landmarks.
    /// - riduce errori di configurazione (come quello appena visto: overlay non si vede).
    /// </summary>
    [Serializable]
    public sealed class SimulationParams
    {
        // ---------------- Mappa ----------------
        public int worldWidth = 64;
        public int worldHeight = 64;

        // ---------------- Localizzazione (usata anche dal logger) ----------------
        public string Language = "it";

        // ---------------- Inventario / Carry capacity ----------------
        public InventoryParams inventory = new InventoryParams();

        // ---------------- Perception cone params (ARCONTIO Standard) ----------------
        public int npcVisionRangeCells = 6;
        public int npcOperationalRangeCells = 0;
        public bool npcVisionUseCone = true;
        public float npcVisionConeSlope = 1.0f;
        public int npcVisionFovDegrees = 90;

        // ---------------- Debug FOV heatmap (view overlay) ----------------
        public DebugFovParams debug_fov = new DebugFovParams();

        // ---------------- Landmark pathfinding (v0.02) ----------------
        public LandmarkSystemParams landmarks = new LandmarkSystemParams();
    }

    // ============================================================
    // INVENTORY
    // ============================================================
    [Serializable]
    public sealed class InventoryParams
    {
        public int inventory_max_units = 3;
    }

    // ============================================================
    // DEBUG FOV
    // ============================================================
    [Serializable]
    public sealed class DebugFovParams
    {
        public bool enabled = false;
        public int window_ticks = 8;
        public bool use_los = true;
        public bool activeNpcOnly = true;
    }

    // ============================================================
    // LANDMARKS (v0.02)
    // ============================================================
    [Serializable]
    public sealed class LandmarkSystemParams
    {
        // Master enable
        public bool enableLandmarkSystem = false;

        // Caps (NPC-side, Day3+)
        public int maxLandmarksPerNpc = 64;
        public int maxEdgesPerNpc = 192;
        public int maxPoiAnchorsPerNpc = 32;

        // Cap (World-side registry, Day2)
        public int maxWorldLandmarks = 512;

        // Adjacency sparsa
        public int maxEdgesPerLandmark = 8;

        // Merge
        public float merge_radius = 1.5f;

        // Candidate detection
        public LandmarkCandidateParams candidate = new LandmarkCandidateParams();

        // Eviction/deactivation params
        public LandmarkEvictionParams eviction = new LandmarkEvictionParams();

        // Retry/backoff params
        public LandmarkRetryParams retry = new LandmarkRetryParams();

        // Debug (view-only)
        public DebugLandmarksParams debug = new DebugLandmarksParams();
    }

    [Serializable]
    public sealed class LandmarkCandidateParams
    {
        public int candidate_cooldown_ticks = 6;
        public int junction_min_exits = 3;
    }

    [Serializable]
    public sealed class LandmarkEvictionParams
    {
        public int eviction_stale_ticks = 600;
        public int eviction_cooldown_ticks = 120;
    }

    [Serializable]
    public sealed class LandmarkRetryParams
    {
        public int retry_backoff_min_ticks = 10;
        public int retry_backoff_max_ticks = 80;
    }

    [Serializable]
    public sealed class DebugLandmarksParams
    {
        public bool enabled = false;
        public bool activeNpcOnly = true;
        public bool microTestDummyGraph = false;
        public int microTestDummyDistanceCells = 2;
    }

    // ============================================================
    // LOADER
    // ============================================================
    public static class SimulationParamsLoader
    {
        public static SimulationParams LoadFromResources(string resourcesPathNoExt)
        {
            var ta = Resources.Load<TextAsset>(resourcesPathNoExt);
            if (ta == null)
            {
                Debug.LogWarning($"[Arcontio] Missing sim params at Resources/{resourcesPathNoExt}.json. Using defaults.");
                return new SimulationParams();
            }

            try
            {
                return JsonUtility.FromJson<SimulationParams>(ta.text) ?? new SimulationParams();
            }
            catch (Exception ex)
            {
                Debug.LogError($"[Arcontio] Failed parsing sim params: {ex}");
                return new SimulationParams();
            }
        }
    }
}
