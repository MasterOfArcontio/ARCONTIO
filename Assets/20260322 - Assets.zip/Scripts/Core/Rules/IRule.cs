using System.Collections.Generic;
using Arcontio.Core.Diagnostics;

namespace Arcontio.Core
{
    /// <summary>
    /// Rule: logica ad alto livello guidata da eventi.
    /// 
    /// - Consuma eventi dal bus
    /// - Produce comandi
    /// - Pu� anche pubblicare nuovi eventi (se serve)
    /// </summary>
    public interface IRule
    {
        void Handle(World world, ISimEvent e, List<ICommand> outCommands, Telemetry telemetry);
    }

    /// <summary>
    /// Esempio: quando un NPC ha fame, se c'� cibo, genera un comando di feed.
    /// In futuro sar� mediato da politica/leggi/privilegi, non automatico.
    /// </summary>
    /*public sealed class BasicSurvivalRule : IRule
    {
        public void Handle(World world, ISimEvent e, List<ICommand> outCommands, Telemetry telemetry)
        {
            if (e is NpcBecameHungryEvent hungry)
            {
                if (world.FoodStocks.Count > 0)
                {
                    outCommands.Add(new FeedNpcCommand(hungry.NpcId, 1));
                    telemetry.Counter("Rule.BasicSurvivalRule.FeedIssued", 1);
                }
                else
                {
                    // Se manca cibo, segnaliamo shortage (esempio)
                    outCommands.Add(new NoOpCommand()); // placeholder
                }
            }
        }
    }*/
    /*
    public sealed class NoOpCommand : ICommand
    {
        public void Execute(World world, MessageBus bus) { }
    }*/
}
