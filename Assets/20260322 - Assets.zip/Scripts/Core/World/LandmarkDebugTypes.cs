using System;
using System.Collections.Generic;

namespace Arcontio.Core
{
    /// <summary>
    /// (v0.02 Day1) Tipi di supporto per osservabilità del sistema Landmark.
    ///
    /// Importante:
    /// - In Day1 NON esiste ancora il LandmarkRegistry né la memoria soggettiva di landmark/edges.
    /// - Questi tipi sono "contratti" view/core per:
    ///   1) Debug report stampabile / visualizzabile nella SummaryOverlay.
    ///   2) Debug overlay (nodi + linee) nella MapGrid view.
    ///
    /// Quando implementeremo i giorni successivi, questi stessi contratti verranno popolati
    /// con dati reali (e non con zeri / liste vuote).
    /// </summary>
    [Serializable]
    public readonly struct NpcLandmarkDebugReport
    {
        public readonly int KnownLandmarksCount;
        public readonly int KnownEdgesCount;
        public readonly int PoiAnchorCount;

        public readonly float ReplansPerMin;
        public readonly float FailuresPerMin;

        public readonly int BlacklistSize;

        public NpcLandmarkDebugReport(
            int knownLandmarksCount,
            int knownEdgesCount,
            int poiAnchorCount,
            float replansPerMin,
            float failuresPerMin,
            int blacklistSize)
        {
            KnownLandmarksCount = knownLandmarksCount;
            KnownEdgesCount = knownEdgesCount;
            PoiAnchorCount = poiAnchorCount;
            ReplansPerMin = replansPerMin;
            FailuresPerMin = failuresPerMin;
            BlacklistSize = blacklistSize;
        }
    }

    [Serializable]
    public readonly struct NpcMacroRouteDebugReport
    {
        public readonly bool HasRoute;
        public readonly int StartNodeId;
        public readonly int TargetNodeId;
        public readonly int RouteNodeCount;
        public readonly int TargetCellX;
        public readonly int TargetCellY;
        public readonly string FailureReason;
        public readonly bool ExecutionActive;
        public readonly bool IsDoingLastMile;
        public readonly int NextRouteNodeIndex;
        public readonly int NextRouteNodeId;
        public readonly int ImmediateTargetX;
        public readonly int ImmediateTargetY;
        public readonly string ExecutionFailureReason;

        public NpcMacroRouteDebugReport(
            bool hasRoute,
            int startNodeId,
            int targetNodeId,
            int routeNodeCount,
            int targetCellX,
            int targetCellY,
            string failureReason,
            bool executionActive,
            bool isDoingLastMile,
            int nextRouteNodeIndex,
            int nextRouteNodeId,
            int immediateTargetX,
            int immediateTargetY,
            string executionFailureReason)
        {
            HasRoute = hasRoute;
            StartNodeId = startNodeId;
            TargetNodeId = targetNodeId;
            RouteNodeCount = routeNodeCount;
            TargetCellX = targetCellX;
            TargetCellY = targetCellY;
            FailureReason = failureReason ?? string.Empty;
            ExecutionActive = executionActive;
            IsDoingLastMile = isDoingLastMile;
            NextRouteNodeIndex = nextRouteNodeIndex;
            NextRouteNodeId = nextRouteNodeId;
            ImmediateTargetX = immediateTargetX;
            ImmediateTargetY = immediateTargetY;
            ExecutionFailureReason = executionFailureReason ?? string.Empty;
        }
    }

    [Serializable]
    public sealed class NpcMacroRouteExecutionState
    {
        public bool Active;
        public bool IsDoingLastMile;
        public int NextRouteNodeIndex;
        public int FinalTargetCellX;
        public int FinalTargetCellY;
        public int ImmediateTargetX;
        public int ImmediateTargetY;
        public string FailureReason = string.Empty;
    }

    /// <summary>
    /// NpcMacroRoutePlan (v0.02 Day4):
    /// route macro calcolata su grafo landmark.
    ///
    /// Nota architetturale importante:
    /// - Questo NON e' ancora il path micro (cella-per-cella).
    /// - E' una sequenza di checkpoint topologici che il Day5 usera' come destinazioni intermedie.
    /// - In Day4 lo usiamo soprattutto come output del planner e come layer di debug osservabile.
    /// </summary>
    [Serializable]
    public sealed class NpcMacroRoutePlan
    {
        public int StartNodeId;
        public int TargetNodeId;
        public int TargetCellX;
        public int TargetCellY;
        public bool Succeeded;
        public string FailureReason = string.Empty;
        public readonly List<int> NodeIds = new List<int>(16);
    }


    /// <summary>
    /// Nodo landmark per overlay view-only.
    /// - cellX/cellY: coordinate su griglia.
    /// - kind: enumerazione leggera (0=generic) così la view può differenziare marker in futuro.
    /// </summary>
    [Serializable]
    public readonly struct LandmarkOverlayNode
    {
        public readonly int CellX;
        public readonly int CellY;
        public readonly int Kind;
        public readonly int NodeId;
        public readonly string Label;

        public LandmarkOverlayNode(int cellX, int cellY, int kind = 0, int nodeId = 0, string label = null)
        {
            CellX = cellX;
            CellY = cellY;
            Kind = kind;
            NodeId = nodeId;
            Label = label ?? string.Empty;
        }
    }

    /// <summary>
    /// Edge landmark per overlay view-only.
    /// - A=(ax,ay), B=(bx,by) in coordinate cella.
    /// - reliability01: 0..1 (quando avremo decay/learning).
    /// </summary>
    [Serializable]
    public readonly struct LandmarkOverlayEdge
    {
        public readonly int Ax;
        public readonly int Ay;
        public readonly int Bx;
        public readonly int By;
        public readonly float Reliability01;

        public LandmarkOverlayEdge(int ax, int ay, int bx, int by, float reliability01 = 1f)
        {
            Ax = ax;
            Ay = ay;
            Bx = bx;
            By = by;
            Reliability01 = reliability01;
        }
    }
}
